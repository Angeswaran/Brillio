--SQL Scripts for creating core data quality tables

create or replace TABLE "DATA_QUALITY"."DQ_CHECK"."DQ_DATA_SOURCE"(ID NUMBER(38) NOT NULL autoincrement start 1 increment 1,
                                                                   ENTITY VARCHAR(500) NOT NULL,
                                                                DATABASE VARCHAR(500) NOT NULL,
                                                                SCHEMA VARCHAR(500) NOT NULL,
                                                                primary key(ID));

create or replace TABLE "DATA_QUALITY"."DQ_CHECK"."DQ_RULE"(ID NUMBER(38) NOT NULL autoincrement start 1 increment 1,
                                                                      RULE_NAME VARCHAR(45) NOT NULL,
                                                                      RULE_LEVEL VARCHAR(45) NOT NULL,
                                                                      RULE_DESCRIPTION VARCHAR(500),
                                                                      RULE_QUERY VARCHAR(16777216),
                                                                      CREATED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
                                                                      UPDATED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
                                                                      primary key(ID));

create or replace TABLE "DATA_QUALITY"."DQ_CHECK"."DQ_TEST_CASE"(ID NUMBER(38) NOT NULL autoincrement start 1 increment 1,
                                                                 TAG_RUN VARCHAR(500) NOT NULL,
                                                             TABLE_NAME VARCHAR(500) NOT NULL,
                                                             FIELD_NAME VARCHAR(500) NOT NULL,
                                                             RULE_NAME VARCHAR(500) NOT NULL,
                                                             INPUT1 VARCHAR(1000),
                                                             INPUT2 VARCHAR(1000),
                                                             INPUT3 VARCHAR(1000),
                                                             EXTRA_FILTER VARCHAR(1000),
                                                             THRESHOLD VARCHAR(500) NOT NULL,
                                                             CREATED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
                                                             UPDATED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
                                                             DATA_SOURCE_ID NUMBER(38),
                                                             primary key(ID));

create or replace TABLE "DATA_QUALITY"."DQ_CHECK"."DQ_TEST_RUN_RESULTS"(RUN_ID NUMBER(38) NOT NULL autoincrement start 1 increment 1,
                                                                     TEST_CASE_ID NUMBER(38),
                                                                     TAG_RUN VARCHAR(500) NOT NULL,
                                                                     TABLE_NAME VARCHAR(500),
                                                                     FIELD_NAME VARCHAR(500),
                                                                     RULE_NAME VARCHAR(500),
                                                                     INPUT1 VARCHAR(1000),
                                                                     INPUT2 VARCHAR(1000),
                                                                     INPUT3 VARCHAR(1000),
                                                                     EXTRA_FILTER VARCHAR(1000),
                                                                     QUERY VARCHAR(16777216),
                                                                     VIOLATED_ROW_COUNT NUMBER(38),
                                                                     DENOMINATOR NUMBER(38),
                                                                     PCT_VIOLATED_ROWS FLOAT,
                                                                     THRESHOLD FLOAT,
                                                                     STATUS VARCHAR(45) COMMENT 'Pass,Fail',
                                                                     EXECUTED_AT TIMESTAMP_NTZ(9),
                                                                     CREATED_AT TIMESTAMP_NTZ(9));


