import snowflake.connector
import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


def snowflake_connector():
    """
    Function for establishing Snowflake Connection

    Returns : Connection, Script
    """
    print('Loading Config file....')
    # defined variables (change based on environment)
    config_location = 'C:/Users/ruchi.saboo/PycharmProjects/DataQualityCheck/'

    # load config
    config = json.loads(open(str(config_location + 'config.json')).read())

    # extract snowflake details from config
    sf_account = config['snowflake']['account']
    sf_user = config['snowflake']['user']
    sf_warehouse = config['snowflake']['warehouse']
    sf_role = config['snowflake']['role']
    sf_database = config['snowflake']['database']
    sf_schema = config['snowflake']['schema']
    sf_password = config['snowflake']['password']
    script = config['snowflake']['snowflake_load_script']

    print('Creating Snowflake Connection')

    # fire up an instance of a snowflake connection
    con = snowflake.connector.connect(
        account=sf_account,
        role=sf_role,
        user=sf_user,
        password=sf_password,
    )

    print('Connecting to DATA_QUALITY DATABASE/SCHEMA')

    # Creating a database, schema, and warehouse if none exists
    con.cursor().execute("CREATE WAREHOUSE IF NOT EXISTS DATA_QUALITY_WH")
    con.cursor().execute("CREATE DATABASE IF NOT EXISTS DATA_QUALITY")
    con.cursor().execute("USE DATABASE DATA_QUALITY")
    con.cursor().execute("CREATE SCHEMA IF NOT EXISTS DQ_CHECK")

    # Using the database, schema and warehouse
    con.cursor().execute("USE WAREHOUSE DATA_QUALITY_WH")
    con.cursor().execute("USE SCHEMA DATA_QUALITY.DQ_CHECK")

    return con, script


def run_sql_script(connection, script):
    """
    Function to create core Data Quality Tables

    Input Param : Connection, Script(SQL file location)
    """
    with open(script, "r") as file:
        for cur in connection.execute_stream(file):
            for ret in cur:
                print(ret)
    cur.close()


def run_select(connection):
    """
    Function to run test cases and store result in DQ_TEST_RUN_RESULTS table

    Input Param : Connection
    """

    tag_run = input("Enter TAG ID to run DQ check : ")
    query = """SELECT TC.*,
    REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(RL.RULE_QUERY,
    '@sourceDatabase',DS.DATABASE),'@sourceSchema',DS.SCHEMA), 
    '@sourceTableName',TC.TABLE_NAME),'@sourceFieldName',TC.FIELD_NAME),
    '@extraFilter',NVL(TC.EXTRA_FILTER,'')),'@input1',NVL(TC.INPUT1,'')),
    '@input2',NVL(TC.INPUT2,'')),'@input3',NVL(TC.INPUT3,'')) AS QUERY_FINAL
    from DATA_QUALITY.DQ_CHECK.DQ_TEST_CASE TC JOIN DATA_QUALITY.DQ_CHECK.DQ_RULE RL
    ON TC.RULE_NAME = RL.RULE_NAME
    JOIN DATA_QUALITY.DQ_CHECK.DQ_DATA_SOURCE DS
    ON TC.DATA_SOURCE_ID=DS.ID 
    AND TAG_RUN = """ + "'" + tag_run + "';"

    cur = connection.cursor()
    cur1 = connection.cursor()
    cur2 = connection.cursor()
    cur.execute(query)

    for c in cur:
        qry = c[-1]
        threshold = int(c[9])
        test_case_id = int(c[0])

        try:
            cur1.execute(c[-1])
            for c1 in cur1:
                tc1 = c1
                print(c1)
                if c1[1] > threshold:
                    status = "Fail"
                else:
                    status = "Pass"

            query = """
            insert into DATA_QUALITY.DQ_CHECK.DQ_TEST_RUN_RESULTS(TEST_CASE_ID, TAG_RUN, TABLE_NAME, 
            FIELD_NAME, RULE_NAME, INPUT1, INPUT2, INPUT3, EXTRA_FILTER, THRESHOLD)
            select ID, TAG_RUN, TABLE_NAME, FIELD_NAME, RULE_NAME, INPUT1, INPUT2, INPUT3, EXTRA_FILTER, 
            THRESHOLD from "DATA_QUALITY"."DQ_CHECK"."DQ_TEST_CASE" where ID = """ + str(test_case_id) +";"
            violated_row_count = tc1[0]
            pct_violated_rows = tc1[1]
            denominator = tc1[2]

        except Exception as E:
            status = "Error"
            qry = str(E).replace("'", '').strip()
            print(qry)

            query = """
            insert into DATA_QUALITY.DQ_CHECK.DQ_TEST_RUN_RESULTS(TEST_CASE_ID, TAG_RUN, TABLE_NAME, 
            FIELD_NAME, RULE_NAME, INPUT1, INPUT2, INPUT3, EXTRA_FILTER, THRESHOLD)
            select ID, TAG_RUN, TABLE_NAME, FIELD_NAME, RULE_NAME, INPUT1, INPUT2, INPUT3, EXTRA_FILTER, 
            THRESHOLD from "DATA_QUALITY"."DQ_CHECK"."DQ_TEST_CASE" where ID = """ + str(test_case_id) +";"

            violated_row_count = "NULL"
            pct_violated_rows = "NULL"
            denominator = "NULL"

        finally:
            cur2.execute(query)
            # print(QUERY)
            update = """update DATA_QUALITY.DQ_CHECK.DQ_TEST_RUN_RESULTS set 
            VIOLATED_ROW_COUNT = """ + str(violated_row_count) + "," + " DENOMINATOR = " + \
                     str(denominator) + "," + " PCT_VIOLATED_ROWS = " + str(pct_violated_rows) + \
                     "," + " QUERY = " + "'" + qry.replace("'","\\'") + "'" + "," + " STATUS = '" + status + "' \
                     where TEST_CASE_ID = " + str(test_case_id) + ";"
            # print(update)
            cur2.execute(update)

    cur.close()
    cur1.close()
    cur2.close()


def main():
    """
    Main Entry point
    """

    conn, script = snowflake_connector()
    try:
        # run SQL script
        # run_sql_script(conn, script)
        run_select(conn)
    except Exception as e:
        raise e


if __name__ == '__main__':
    main()
