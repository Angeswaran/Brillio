from os import replace
import sys
import pyspark.sql as sql
import traceback
from io import StringIO, BytesIO 
import pandas as pd 
import json 
import csv 
from pyspark.sql.functions import *
from pyspark.sql.functions import lit
from pyspark.sql.types import *
import numpy as np
import logging
import boto3
from datetime import datetime,timedelta  
import awswrangler as wr
import pandas as pd
import pytz
import boto3
from botocore.exceptions import ClientError
ist = pytz.timezone('Asia/Kolkata')
# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
spark = sql.SparkSession.builder.getOrCreate()

message_dict ={}
failed_tables=[]

"""
Function Name: get_config_details

Description:
Retrive config details from Config file which is stored in S3

Input:
1. config_s3_bucket - S3 Bucket name where config file stored.
2. config_s3_filepath - Location of Config file in S3 with file name. 

Output:
1. Whole content of the Config file in JSON format.
"""
def get_config_details(config_s3_bucket, config_s3_filepath):
    s3 = boto3.client("s3")    
    content_object = s3.get_object(
        Bucket=config_s3_bucket,
        Key=config_s3_filepath,
    )
    file_content = content_object["Body"].read().decode("utf-8")
    json_content = json.loads(file_content)
    return(json_content)

"""
Function Name : get_secret

Description   : Method for fetching secrets from the Secret Manager

Parameters    :
secret_name                     - Name of the secret

"""
def get_secret(secret_name):
    secret_client = boto3.client('secretsmanager')
    response = secret_client.get_secret_value(SecretId=secret_name)
    secret_value = response['SecretString']
    secret_data = json.loads(secret_value)
    return(secret_data)



"""
Function Name : s3_write

Description   : Method for writing the data into S3

Parameters    :
s3_output                       - write directory for S3 ingestion
read_data                       - data fetched from Oracle DB
write_mode                      - Mode of writing the data(append (or) overwrite)
table_name                      - Name of the table

"""
def s3_write(s3_output,read_data,write_mode):    
    try:
        if(write_mode == "append"):        
            read_data.write.format("parquet").mode(write_mode).save(s3_output)
        elif(write_mode == "overwrite"):
            read_data.write.format("parquet").mode(write_mode).save(s3_output) 
        
    except Exception as e:
        print("A error occurred:",str(e)) 

"""
Function Name : archiving

Description   : Method for archiving the data written in raw zone and also to delete the tables
                which are staying for more than 15 days

Parameters    :
Bucket_name                     - Name of the Bucket
s3_output                       - Directory pointing to raw zone
archive_location                - S3 location for archive to store
table_name_list                 - List of table names to be archived

"""
def archiving(Bucket_name,s3_output,archive_location,table_name_list):
    s3 = boto3.client('s3')
    current_date = datetime.now().strftime("%Y-%m-%d")
    archive_location_with_date = archive_location + current_date
    source_bucket=Bucket_name
    destination_bucket = Bucket_name
    
    destination_folder_prefix=archive_location_with_date
    #table_list = [item.strip(" '") for item in table_name_list.strip("[]").split(',')]
    s3_output=s3_output.replace(f"s3://{Bucket_name}/","")
    table=table_name_list
    #for table in table_list:
    source_folder_prefix= s3_output+table+"/"
    response = s3.list_objects_v2(Bucket=source_bucket,Prefix=source_folder_prefix)
    
    for objects in response.get('Contents',[]):
        source_key = objects["Key"]
        filename = source_key.split('/')[-1]
        destination_key= destination_folder_prefix.replace(f"s3://{destination_bucket}/","")

        s3.copy_object(
            CopySource={'Bucket':source_bucket,'Key':source_key},
            Bucket=destination_bucket,
            Key=destination_key+"/"+table+"/"+filename
        )
    # logger.info(f"archiving completed for {table} table")
    
    logger.info("***********Archive deletion is in progress*************")
    fifteen_days_ago = datetime.now() - timedelta(days=15)
    fif = fifteen_days_ago.strftime("%Y-%m-%d")
    logger.info(f"----------------------Folder to be deleted in raw_archive folder-------------{fif}")
    archive_location = archive_location.replace(f"s3://{Bucket_name}/","")
    prefix =archive_location+fif+"/"
    logger.info(f" ******************Path:*******{prefix}")
    try:
        response = s3.list_objects_v2(Bucket=Bucket_name, Prefix=prefix)    
        # Check if 'Contents' key is present in the response
        if 'Contents' in response:
            # Prepare the list of objects to be deleted
            objects_to_delete = [{"Key": key["Key"]} for key in response["Contents"]]
            logger.info(f"*****Objects to be deleted:*******{objects_to_delete}")
            # Delete objects
            s3.delete_objects(Bucket=Bucket_name, Delete={"Objects": objects_to_delete})
            
            logger.info(f"**********Files inside {prefix} have been deleted*************")
        else:
            logger.info("No objects found in the specified location")
            
    except s3.exceptions.ClientError as e:
        if e.response['Error']['Code'] == '404':
            logger.info("Object Not Found in the location")
        else:
            logger.error(f"An error occurred: {e}")  


"""
Function Name : refresh_glue_table_metadata

Description   : Method to store the parquet metadata in the glue database

Parameters    :
Path                            - Location of source tables in raw zone
database                        - Name of the glue database name
table                           - Name of the table
description                     - Description of the metadata
columns_comments                - column comments
parameters                      - parameters

"""
def refresh_glue_table_metadata(path,database,table,description,columns_comments,parameters):
        wr.s3.store_parquet_metadata(
            path= path + '/',
            database=database,
            table=table,
            dataset=True,
            mode="overwrite",
            description=description,
            parameters= parameters,
            columns_comments=columns_comments,
        )


def athena_query(database_name, sql_query):
    logger.info("inside athena_query execution")    
    df_results = wr.athena.read_sql_query(sql=sql_query, database=database_name, ctas_approach=False, s3_output='s3://gd-dp-lm-dev2/lm-dev/publish_temp/' )
    # df_results_1 = df_results.astype(object).where(pd.notnull(df_results),'')
    df_results_1 = df_results.astype(str).replace("nan"," ")
    logger.info("inside athena_query execution-END")
    logger.info("******* pandas DF result******", df_results_1)
    df_results_1.info()
    df_query_results = spark.createDataFrame( df_results_1) 
    df_query_results.printSchema()
    logger.info("******* Spark DF result******",df_query_results)
    return df_query_results

"""
Function Name: read_table_data_using_wrangler

Description:
Read data from particular Athena table through AWS Wrangler approach

Input:
1. database_name - Database name of the table.
2. table_name - Table name where we want to fetch data. 

Output:
1. Fetched Athena table data in Pandas dataframe format. 
"""       
def read_table_data_using_wrangler(database_name, table_name):
    df_raw = wr.athena.read_sql_query(sql="select * from " + table_name, database=database_name, ctas_approach=True)
    return df_raw

"""
Function Name: read_table_data_using_glue_catalog

Description:
Read data from particular Athena table through Spark approach

Input:
1. glueContext - Glue context to create dynamic dataframe
2. database_name - Database name of the table.
3. table_name - Table name where we want to fetch data. 

Output:
1. Fetched Athena table data in Spark dataframe format. 
"""        
def read_table_data_using_glue_catalog(glueContext, database_name, table_name):
    dynamic_df_raw = glueContext.create_dynamic_frame.from_catalog(database=database_name,table_name=table_name)
    df_raw = dynamic_df_raw.toDF()
    return df_raw
    
"""
Function Name: drop_glue_table_using_spark

Description:
Drop existing table from Athena, So that we can create and insert new data into Athena table.

Input:
1. sparkSession - Delete query which we want to execute on top of Athena table. 
2. databasename - Database name of the table.
3. tablename - Table name which we want to drop.

Output:
1. Nothing will be return as it executed mentioned query only. 
"""     
def drop_glue_table_using_spark(sparkSession, databasename, tablename):
    logger.info(f"target_database:{databasename}")
    logger.info(f"target_table:{tablename}")
    sql_stmnt = "DROP TABLE IF EXISTS " + databasename + "." + tablename
    #logger.info("Drop SQL:",sql_stmnt)
    sparkSession.sql(sql_stmnt)
    
"""
Function Name: drop_glue_table_using_wrangler

Description:
Drop existing athena table using AWS Wrangler. So that we can create and insert new data into the table.

Input:
1. drop_query - Drop query which we want to drop the table.
2. database_name - Database name of the table.
3. table_name - Table name which we want to drop. 

Output:
1. Nothing will be return as it executed mentioned query only. 
"""   
def drop_glue_table_using_wrangler(drop_query, database_name, table_name):
    try:
        if wr.catalog.does_table_exist(database=database_name, table=table_name):
            query_execution_info = wr.athena.start_query_execution(
                        sql=drop_query,
                        database=database_name,
                        wait=True,
                    )
        else:
            logger.info("table does not exist in database")
        logger.info("delete_records_from_iceberg_table - End")
    except Exception as e:
        logger.error("Exception: Error occured in delete_records_from_iceberg_table method, Error is - {}".format(str(e)))
        raise e

"""
Function Name: write_iceberg_table_using_wrangler

Description:
This method helps to write data into Iceberg table using Wrangler approach.

Input:
1. df_data - Dataframe data which will be written to Iceberg table from Pandas dataframe.
2. database_name - Database name of the target table.
3. table_name - Name of table where we want to write data. 
4. table_location - Underlying Table location of the target Table. 
5. temp_location - Temp. Location for storing data before writing it into Iceberg Table.
6. target_schema - Schema details which helps to enforce while writing data into Iceberg Table. 

Output:
1. Nothing will be return as it write data into Target table. 
"""
def write_iceberg_table_using_wrangler(df_data, database_name, table_name, table_location, temp_location, target_schema): 
    wr.athena.to_iceberg(
            df = df_data,
            database = database_name,
            table = table_name,
            table_location = table_location,
            temp_path = temp_location,
            dtype = target_schema,
            keep_files=False,
        )
        
"""
Function Name: write_iceberg_table_using_spark

Description:
This method helps to write data into Iceberg table using Spark approach.

Input:
1. sparkSession - Spark Session which helps to write data into Refined Iceberg table
2. df_curated - Curated data which will be ingested into refined layer as in Spark dataframe. 
3. iceberg_table - Table name of Refined layer with database name
4. iceberg_path - Residing location of Refined layer table. 

Output:
1. Nothing will be return as it write data into refined Layer table. 
"""
def write_iceberg_table_using_spark(sparkSession, df_curated, iceberg_database, iceberg_table, iceberg_path):
    try:
        df_curated.createOrReplaceTempView("curated_data_" + iceberg_table)
        #sql_stmnt = "CREATE TABLE " + iceberg_database + "." + iceberg_table  + " USING iceberg LOCATION " +  iceberg_path + " AS SELECT * FROM curated_data_"  + iceberg_table
        
        sql_stmnt = f"""
                CREATE TABLE {iceberg_database}.{iceberg_table}
                USING iceberg
                LOCATION '{iceberg_path}'
                AS SELECT * FROM curated_data_{iceberg_table}"""
        sparkSession.sql(sql_stmnt)
    except Exception as e:
        logger.error("Exception: Error occured in write_into_iceberg_table method, Error is - {}".format(str(e)))
        raise e 

"""
Function Name: trigger_notification

Description:
This method helps to send SQS message to the Email Notification System

Input:
1. service_name - Service name where you want to send notification.
2. cloudwatch_log_url - Cloudwatch URL which helps to track/troubleshoot the job logs.  
3. event_description - Description of the event which may be Success or Failure description. 
4. event_type - Type of event whether it may be INFO, ERROR.
5. notification_flag - notification_flag which helps to enable/disable Notification. 
6. solution_name - Solution name/Project name to be passed to the Email template.
7. sqs_trigger_notification - SQS link where email template will be drafted. 
8. function_name - Name of the function where job got errored out.  

Output:
1. Nothing will be return as it send message to Notification system. 
"""        
def trigger_notification(service_name, cloudwatch_log_url, event_description, event_type, notification_flag, solution_name, sqs_trigger_notification, function_name = ""):
    sqs = boto3.client('sqs')
    event_description_message = json.dumps(event_description)        
    resp = sqs.send_message(
        QueueUrl=sqs_trigger_notification,
        MessageBody=(
            '{"event_type": "' + event_type + '" , "solution_name": "' + solution_name + '", "service_name": "' + service_name + '", "function_name": "' + function_name + '", "event_description": ' +  event_description_message + ', "cloudwatch_log_url": "' + cloudwatch_log_url + '", "notification_flag": "' + notification_flag + '"}'
        )
    )
    return 1