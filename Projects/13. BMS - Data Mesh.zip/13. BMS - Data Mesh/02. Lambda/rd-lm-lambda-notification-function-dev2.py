import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

email_from = os.environ['email_from']
email_to = os.environ['email_to']
email_cc = os.environ['email_cc']
bms_ces_deadletter_sqs_url = os.environ['bms_ces_deadletter_sqs_url']
bms_ces_sqs_url = os.environ['bms_ces_sqs_url']

email_message = "test message"
email_subject = "Test Email"

sqs = boto3.client('sqs')

def send_email(email_from, email_to, email_cc, solution_name, service_name, cloudwatch_log_url, 
        function_name, event_description, event_type, bms_ces_deadletter_sqs_url, bms_ces_sqs_url):
    
    email_message = """\
    <html>
        <head>
        <style>
            table, th, td {
                border: 1px solid black;
                border-collapse: collapse;
            }
            th, td {
                padding: 5px;
                text-align: left;    
            }    
        </style>
        </head>
    <body> """ 
    if (event_type.upper() == "ERROR"):   
        email_message = email_message + """ <p>An exception has occurred while executing object as summarized below.</p> """
    else:
        email_message = email_message + """ <p>The service has completed successfully as summarized below. </p> """
         
    email_message = email_message + """ <table>
        <tr><td>Solution Name</td><td>""" + solution_name + """</td></tr>
        <tr><td>Service Name</td><td>""" + service_name + """</td></tr>
        <tr><td>CloudWatch Log</td><td>""" + cloudwatch_log_url + """</td></tr> """

    if (event_type.upper() == "ERROR"):   
        email_message = email_message + """ <tr><td>Function Name</td><td>""" + function_name + """</td></tr> """
    elif (event_type.upper() == "WARN"):
        email_message = email_message + """ <tr><td>Function Name</td><td>""" + function_name + """</td></tr> """
    else:
        email_message = email_message + """ <tr><td>Function Name</td><td>N/A</td></tr> """
        
    email_message = email_message + """ <tr><td>Description</td><td>""" + event_description + """</td></tr>
    </table>    
    </body>
    </html>
    """

    email_subject = event_type.upper() + ": " + solution_name + " - " + service_name

    # Create the payload to be sent
    message = {
        'Cc' : email_cc,
        'From' : email_from,
        'Message' : email_message,
        'SQSUrl': bms_ces_deadletter_sqs_url,
        'Subject' : email_subject,
        'To' : email_to,
        'Type': 'Email',
        'VitalizeId' : '428096'        
    }

    # Send the message
    try:
        response = sqs.send_message(
            QueueUrl=bms_ces_sqs_url,
            MessageBody=json.dumps(message)
        )
        print(response)
    except:
        print('ERROR: Unable to send message.')

def handler(event, context):
    #sqs = boto3.client('sqs')
    
    #solution_name = "Large Molecule"
    #service_name = "raw_to_refined"
    #cloudwatch_log_url = "cloudwatch_log_url"
    #function_name = "function_name"
    #event_description = "test"
    #event_type = "info"
    #event_environment = "dev"

    for record in event['Records']:
        logger.info('Incoming Message is - ' + str(record))
        
        #Get the message
        input_message = json.loads(record["body"], strict=False)
        logger.info('Message Body: ' + str(input_message))
        logger.info("Event descritption is - {}".format(input_message['event_description']))

        solution_name = input_message['solution_name']
        service_name = input_message['service_name']
        cloudwatch_log_url = input_message['cloudwatch_log_url']
        function_name = input_message['function_name']
        event_description = input_message['event_description']
        event_type = input_message['event_type']
        notification_flag = input_message['notification_flag']
        
        if(notification_flag.upper() == "Y"):        
            send_email(email_from, email_to, email_cc, solution_name, service_name, cloudwatch_log_url, function_name, event_description, event_type, bms_ces_deadletter_sqs_url, bms_ces_sqs_url)
        else: 
            logger.info("Email will not be triggered due to notification_flag is not enabled")
            