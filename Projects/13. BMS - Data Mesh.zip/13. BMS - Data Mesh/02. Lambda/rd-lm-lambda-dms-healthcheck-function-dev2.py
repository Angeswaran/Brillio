import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dms_client = boto3.client('dms')

def trigger_notification(service_name, cloudwatch_log_url, event_description, event_type, notification_flag, solution_name, sqs_trigger_notification, function_name = ""):
    sqs = boto3.client('sqs')
    event_description_message = json.dumps(event_description)        
    resp = sqs.send_message(
        QueueUrl=sqs_trigger_notification,
        MessageBody=(
            '{"event_type": "' + event_type + '" , "solution_name": "' + solution_name + '", "service_name": "' + service_name + '", "function_name": "' + function_name + '", "event_description": ' +  event_description_message + ', "cloudwatch_log_url": "' + cloudwatch_log_url + '", "notification_flag": "' + notification_flag + '"}'
        )
    )
    return 1
    
def get_replication_instance_details(replication_instance_name):
    replication_instance_details = dms_client.describe_replication_instances(Filters=[{'Name': 'replication-instance-id', 'Values': [replication_instance_name]}])
    return replication_instance_details
    
    
def get_replication_task_status(replication_task_name):
    response = dms_client.describe_replication_tasks()
    replication_tasks = response["ReplicationTasks"]

    for task in replication_tasks:
        if task["ReplicationTaskIdentifier"] == replication_task_name:
            task_status = task["Status"]
    return task_status


def handler(event, context):
    replication_instance_name = event['replication_instance_name']
    replication_task_name = event['replication_task_name']
    
    solution_name = os.environ['solution_name']
    sqs_trigger_notification = os.environ['sqs_trigger_notification']
    notification_flag = os.environ['notification_flag']
        
    service_name = context.function_name
    service_run_id = context.aws_request_id
    function_name = service_name
    cloudwatch_log_url = "CloudWatch > Log groups > " + context.log_group_name + " > " + context.log_stream_name
    event_type = "Error"
    
    try:
        # Get existing replication instance details
        replication_instance_details = get_replication_instance_details(replication_instance_name)
        logger.info("replication_instance_details - {}".format(replication_instance_details))
        replication_instance_status = replication_instance_details['ReplicationInstances'][0]['ReplicationInstanceStatus']
        if(replication_instance_status != "available"):
            logger.info("Current status of instance: {} is - {}".format(replication_instance_name, replication_instance_status))
            event_description = "DMS - Replication Instance - " + replication_instance_name + " is not running now. Can you please check and Fix."
            output = trigger_notification(service_name, cloudwatch_log_url, event_description, event_type, notification_flag, solution_name, sqs_trigger_notification, function_name = "")
            if(str(output) != "1"):
                logger.info(output)
                logger.info("Message is not delivered to audit entry SQS")
            else:
                logger.info(output)
                logger.info("Message is delivered to audit entry SQS successfully..!!")
        else:
            logger.info("Current status of instance: {} is - {}".format(replication_instance_name, replication_instance_status))
        
        # Get existing replication task details
        replication_task_status = get_replication_task_status(replication_task_name)
        if(replication_task_status != "running"):
            logger.info("Current status of replication task: {} is - {}".format(replication_task_name, replication_task_status))
            event_description = "DMS - Replication Task - " + replication_task_name + " is not running now. Can you please check and Fix."
            output = trigger_notification(service_name, cloudwatch_log_url, event_description, event_type, notification_flag, solution_name, sqs_trigger_notification, function_name = "")
            if(str(output) != "1"):
                logger.info(output)
                logger.info("Message is not delivered to audit entry SQS")
            else:
                logger.info(output)
                logger.info("Message is delivered to audit entry SQS successfully..!!")
        else:
            logger.info("Current status of instance: {} is - {}".format(replication_task_name, replication_task_status))
    except Exception as e:
        logger.error("Error occured while doing health check for DMS Replication instance and Tasks. Error description is - {}".format(str(e)))
        