from os import replace
import sys
from awsglue.transforms import *                                                                                           
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import lit
import boto3
from datetime import datetime, timedelta
import logging
from threading import Thread
import pytz
ist = pytz.timezone('Asia/Kolkata')
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)
args = getResolvedOptions(sys.argv, ["JOB_NAME"])
job_args = getResolvedOptions(sys.argv,["config_s3_filepath","config_s3_bucket","utility_s3_filepath","sqs_trigger_notification","solution_name","notification_flag","source_name"])
jobName = args["JOB_NAME"]
jobRunId = args['JOB_RUN_ID']

logStreamName = "CloudWatch > Log groups > /aws-glue/jobs/output/" + jobRunId
errorlogStreamName = "CloudWatch > Log groups > /aws-glue/jobs/error/" + jobRunId

notification_flag = job_args["notification_flag"]
solution_name = job_args["solution_name"]
sqs_trigger_notification =job_args["sqs_trigger_notification"]
source_name = job_args["source_name"]
infoEventType = "INFO"
errorEventType = "ERROR"


fetch_size=100000
block_size: str = str(128*1024*1024)
is_failed=False
message_dict = {}
failed_tables = []
conf=(
    SparkConf()
        .set("spark.hadoop.parquet.block.size",block_size)
        .set("spark.hadoop.dfs.blocksize",block_size)
        .set("spark.hadoop.dfs.block.size",block_size)
        .set("spark.hadoop.fetchsize",fetch_size)
)
sc = SparkContext(conf=conf)
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "LEGACY") 
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED") 
utility_s3_filepath = job_args["utility_s3_filepath"]
# Add reference files
spark.sparkContext.addPyFile(utility_s3_filepath)
#importing the utility file
import gd_dp_common_utility as dpcu

config_object_key = job_args["config_s3_filepath"]
bucket = job_args["config_s3_bucket"]
s3 = boto3.client('s3')

"""
Function Name : execute_jdbc_query_and_s3write

Description   : Method for fetching data from Database and calling the s3_write, archiving and metadata functions

Parameters    :
Bucket_name                     - Name of the Bucket
s3_output                       - write directory for S3 ingestion
archive_output                  - archiving directory for S3 ingestion
jdbc_driver                     - Oracle driver name
table_name_list                 - List of table names need to ingested
write_mode                      - Mode of writing (append or overwrite)
secret                          - Retrieved secret value
catalog_DB                      - Glue catalog database name 
glue_connection_name            - Glue catalog connection name
source_name                    - source system name
sqlquery                        - custom SQL query with required columns and filters
"""
def execute_jdbc_query_and_s3write(Bucket_name,s3_output,archive_output,jdbc_driver,schema_name,table_name,write_mode,secret,catalog_DB,glue_connection_name,source_name,sqlquery=""):
    
 
    try:
        if "." not in table_name:
            dbtable=f"{schema_name}.{table_name}"
        else:
            dbtable=table_name
        
        connection_oracle_options={"useConnectionProperties":True,"connectionName":glue_connection_name,"dbtable":dbtable}
        
        if sqlquery != "":
            query={"sampleQuery":sqlquery}
            connection_oracle_options.update(query)
        
        logger.info("dbtable:"+dbtable)
        logger.info("sql Query:"+sqlquery)
        logger.info(connection_oracle_options)
        
        logger.info("Reading source data:")
        
        dyf=glueContext.create_dynamic_frame.from_options(connection_type="oracle", connection_options=connection_oracle_options)
        
        
        
        logger.info("Table name:" +dbtable+" Glue dynamic frame count:"+ str(dyf.count()))
        df = dyf.toDF()
        logger.info("Table name:" +dbtable+" Spark dataframe count:"+str(df.count()))
        
        df_withSourceName = df.withColumn("source_name",lit(source_name))
        
        # s3 output is suffixed with table name to create the table name as the folder name
        s3_output1 = s3_output + table_name
        dpcu.s3_write(s3_output1,df_withSourceName,write_mode)
        dpcu.message_dict[table_name]["ingestion_status"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": ingestion for {table_name} completed"
        dpcu.refresh_glue_table_metadata(s3_output1,catalog_DB,table_name,'genedata large molecule tables',{},{"owner": "test@bms.com"})
        dpcu.message_dict[table_name]["cataloging_status"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f":  cataloging for {table_name} completed"   
        dpcu.archiving(Bucket_name,s3_output,archive_output,table_name)
        dpcu.message_dict[table_name]["archiving_status"] =datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f":  archiving for {table_name} completed"

    except Exception as e:
        global is_failed
        is_failed=True
        global failed_tables
        failed_tables.append(table_name)
        logger.error("******************************Error************************************")
        logger.error(e,exc_info=True)
        



""" Function call for getting values for config and storing the returned data in read_config_data variable"""
read_config_data= dpcu.get_config_details(bucket,config_object_key)


write_location = read_config_data["output_directory"]
secret_name = read_config_data["secret_name"]
write_mode = read_config_data["write_mode"]
jdbc_driver = read_config_data["driver_name"]
archive_location = read_config_data["archive_directory"]
Bucket_name = read_config_data["Bucket_name"]
TABLES_LIST = read_config_data["TABLE_LIST"]
schema=read_config_data["Schema"]
catalog_DB=read_config_data["Catalog_database"]
thread_count = read_config_data["thread_count"]
glue_connection_name = read_config_data["glue_connection_name"]
customSQL=read_config_data["customSQL"]



""" Function call for getting secrets from the secret manager"""
read_secret = dpcu.get_secret(secret_name)

""" Function call for fetching the data from Oracle DB and writing it into S3 using threading technique"""
try:   
    
    TABLE_LIST = [item.strip(" '") for item in TABLES_LIST.strip("[]").split(',')]
    logger.info(TABLE_LIST)
    THREADS = thread_count
    # list of table splitted based on the thread count
    splits = [TABLE_LIST[x:x+THREADS] for x in range(0, len(TABLE_LIST), THREADS)]
    logger.info(splits)
    
    for k in splits:
        logger.info(k)
        threads=[]
        for TABLE_NAME in k:
            dpcu.message_dict[TABLE_NAME] ={}
            logger.info(TABLE_NAME)
            
            if TABLE_NAME in customSQL:
                sqlquery=customSQL[TABLE_NAME]
            else:
                sqlquery=""


            process=Thread(target=execute_jdbc_query_and_s3write,args=[Bucket_name,write_location,archive_location,jdbc_driver,schema,TABLE_NAME,write_mode,read_secret,catalog_DB,glue_connection_name,source_name,sqlquery])
            process.start()
            threads.append(process)
               
        for process in threads:
            process.join()
    
    if is_failed == True:        
        raise Exception('Failed on some tables.. Please check log for more details')
        
    logger.info("******FINAL STATUS MESSAGE******")
    
    for table, statuses in dpcu.message_dict.items():
        logger.info(f"Table: {table}")
        for status_name, status_value in statuses.items():
            logger.info(f"{status_name}: {status_value}")
            
    dpcu.trigger_notification(jobName, logStreamName, f'Ingestion Completed for {jobName} with genedata as a source', infoEventType, notification_flag, solution_name, sqs_trigger_notification)  
    
except Exception as e:
    logger.info("Invalid tables :",failed_tables)
    logger.info("******************************Error************************************")
    logger.error(e,exc_info=True)
    dpcu.trigger_notification(jobName, errorlogStreamName, 'Code execution failed for ' + jobName, errorEventType, notification_flag, solution_name, sqs_trigger_notification)  
    raise e

job.commit()

