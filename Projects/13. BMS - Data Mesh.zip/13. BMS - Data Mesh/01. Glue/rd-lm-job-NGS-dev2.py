import pyarrow
import sys, boto3, datetime, json, time
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
#default glue import
import sys
#standard library of functions to interact with AWS services via APIs - needed for DynamoDB, SecretsManager, and S3
import boto3
#used for boto3-based exception handling
from botocore.exceptions import ClientError
#StringIO and io are required to read data from s3
from io import StringIO, BytesIO
import io
#standard data libraries - pandas is used for all transformations
import pandas as pd
import csv
import json
import logging
#necessary for getting yesterday's date
from datetime import datetime, timedelta
import awswrangler as wr

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "sqs_trigger_notification", "notification_flag", "solution_name"])

jobName = args["JOB_NAME"]
jobRunId = args['JOB_RUN_ID']

config_s3_bucket = args["config_s3_bucket"]
config_s3_filepath = args["config_s3_filepath"]
utility_s3_filepath =args["utility_s3_filepath"]
sqs_trigger_notification =args["sqs_trigger_notification"]
notification_flag = args["notification_flag"]
solution_name = args["solution_name"]

logStreamName = "CloudWatch > Log groups > /aws-glue/jobs/output/" + jobRunId
errorlogStreamName = "CloudWatch > Log groups > /aws-glue/jobs/error/" + jobRunId

infoEventType = "INFO"
errorEventType = "ERROR"

# Configuration for Iceberg settings
conf = SparkConf()

# Initializing the SparkContext, GlueContext and SQL Context
sparkContext = SparkContext(conf=conf)
glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

# Import custom common functions from utility
import gd_dp_common_utility as dpcu

# Creating athena client for accessing athena tables
athena_client = boto3.client('athena')

def get_data_from_s3(ngs_bucket, current_s3_key):
    try:
        #initialize boto3 client
        s3 = boto3.client('s3')
        
        obj = s3.get_object(Bucket=ngs_bucket, Key=current_s3_key)
        
        #use pandas to read_csv the s3 file, this function returns a dataframe-type object
        return pd.read_csv(obj['Body'])
    except Exception as e:
        logger.error("Error occured in get_data_from_s3. Error description is - {}".format(str(e)))


def get_data_from_s3_excel(ngs_bucket, current_s3_key):
    try:
        #initialize boto3 client
        s3 = boto3.client('s3')
        
        obj = s3.get_object(Bucket=ngs_bucket, Key=current_s3_key)
        
        #use pandas to read_excel s3 file, this function returns a dataframe-type object
        df = pd.read_excel(obj['Body'].read(), engine="openpyxl")
        
        return df
    except Exception as e:
        logger.error("Error occured in get_data_from_s3_excel. Error description is - {}".format(str(e)))

def transform_ngs_results_data(s3_key, original_df):
    try:
        #create a list of all columns
        list_all_columns = original_df.columns.tolist()
        
        #all columns will be either "metadata" or "measurement columns". Metadata columns are hardcoded based on the requirements
        all_row_metadata = ['literal_pos','res_mutant','parent_ab_pos_mutant','is_parent','vh:full_aa','vl:full_aa','locus','ab_scheme','ab_pos','res_scanned_parent','is_mutated','res_original_parent','res_germline','moe_res_exp','scan_region','is_vernier_zone']
        
        #measurement columns are any columns that have a : in them, based on the requirements
        list_measurement_columns = [column_name for column_name in list_all_columns if ':' in column_name]
        
        #convert from wide form to long form. id_vars corresponds to the columns that will not pivot. list_measurement_columns corresponds to values that will pivot. The new column 
        #will be antigen:measurement, and the values will be result_value. 
        final_df = pd.melt(original_df, id_vars=all_row_metadata, value_vars=list_measurement_columns, var_name = 'antigen:measurement', value_name = 'result_value')
        
        #split the antigen:measurement column based on the column. For example, the antigen:measurement column will have a value: Hu-0.2nM: frac. After splitting, two columns are created
        #antigen column is based on value left of the colon, result_type is based on value right of the colon
        final_df[['antigen_sample', 'result_type']] = final_df['antigen:measurement'].str.split(':', expand=True)
        
        #drop the antigen:measurement column since it was split into two other columns
        final_df = final_df.drop(columns=['antigen:measurement'])
        
        #requirements requested adding the s3 location of the ngs results file
        final_df['ngs_results_file_s3_location'] = s3_key
        
        #the group_name value is parsed from the name of the CSV file
        final_df['group_name'] = s3_key.split('/')[-1].split('.csv')[0]
        
        #uncomment when production-ready - actual filepath will have sample_metadata and er_metadata in the project subdirectory, indicated as P-*
        #final_df['er_metadata_file_s3_location'] = s3_key.split('/')[0] + '/PAD2_ER_Metadata.xlsx'
        #final_df['sample_metadata_file_s3_location'] = s3_key.split('/')[0]  + '/PAD2_Sample_Metadata.xlsx'
        
        #hard coded for test purposes in order to work with data stored in Large Molecule AWS account
        final_df['er_metadata_file_s3_location'] = s3_key.split('/')[0] + '/' + s3_key.split('/')[1] + '/PAD2_ER_Metadata.xlsx'
        final_df['sample_metadata_file_s3_location'] = s3_key.split('/')[0] + '/' + s3_key.split('/')[1] + '/PAD2_Sample_Metadata.xlsx'
        
        #rename column, NGS360 output shows 'is_mutated' -> rename to 'is_mutable' per STTM requirements
        final_df = final_df.rename(columns={'is_mutated': 'is_mutable'})
        
        #return the final transformed ngs data
        return final_df
    except Exception as e:
        logger.error("Error occured in transform_ngs_results_data. Error description is - {}".format(str(e)))

def upload_final_data_product(final_df, bucket, key,s3_location,catalog_DB,table_name, dt_type):    
    try:
        logger.info("Uploading file to S3: {} ".format(str(key)))
        csv_buffer = StringIO()

        if len(dt_type) == 0:
            wr.s3.to_parquet(df=final_df, path=s3_location,dataset=True,database=catalog_DB, table=table_name,mode='overwrite')
        else:
            wr.s3.to_parquet(df=final_df, path=s3_location,dataset=True,database=catalog_DB, table=table_name,dtype=dt_type,mode='overwrite')
        
        if 'xlsx' in str(key):
            final_df.to_excel("s3://" + bucket + "/" + key, index=False)
        else:
            final_df.to_csv(csv_buffer, index=False)
            #Create S3 object
            s3_resource = boto3.resource("s3")
            #Write buffer to S3 object
            s3_resource.Object(bucket, key).put(Body=csv_buffer.getvalue())
    except Exception as e:
        logger.info("Uploading data product failed due to the following error - {}".format(str(e)))
    
def dynamodb_status_check(dynamodb_tablename, file_key):
    try:
        dynamodb = boto3.client('dynamodb')
    
        logger.info("Checking for filename: {} ".format(str(file_key)))
        response = dynamodb.get_item(TableName = dynamodb_tablename, Key={'filename': {'S':file_key}})
    
        logger.info("DynamoDB Check response is: {} ".format(str(response)))
        if 'Item' in response.keys():
            logger.info("file found in DynamoDB")
            return True
        else:
            logger.info("file not found in DynamoDB")
            return False
    except Exception as e:
        logger.error("Error occured in dynamodb_status_check. Error description is - {}".format(str(e)))
        
def retrieve_env_variables_from_secrets_manager():    
    #config is the same between DEV and PRD environment since there is only one environment for NGS data
    config_secret_name = "NGS-Configuration"
    
    #using east region - arbitrary decision, can be updated to a different region as long as the new secret is created in that new region
    config_region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=config_region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=config_secret_name
        )
    except ClientError as e:
        logger.info(str(e))
        raise e

    return get_secret_value_response['SecretString']

def initialize_data_product(bucket, key):
    try:
        s3 = boto3.client('s3')
        
        try: 
            #get current data product
            obj = s3.get_object(Bucket=bucket, Key=key)
            
            return pd.read_csv(obj['Body'])
        except:
            #else return empty dataframe as the data product has not been built yet
            return pd.DataFrame()
    except Exception as e:
        logger.error("Error occured in initialize_data_product. Error description is - {}".format(str(e)))

# ('bmsrd-ngs-data/bmsrd-ngs-data-daily/')  'T01-00Z/manifest.json'
def get_runs_from_inventory_report():
    try:
        #return ['NGS/SevenBridges/PAD2_CL-195282_VL.csv','NGS/SevenBridges/PAD2_CL-195282_VH.csv','NGS/SevenBridges/PAD2_CL-187843_VL.csv','NGS/SevenBridges/PAD2_CL-187843_VH.csv']
        return ['NGS/SevenBridges/PAD2_CL-187843_VL.csv']
        #client = boto3.client('s3')
        #
        #yesterday = datetime.now() - timedelta(1)
        #
        #yesterday_date_as_string = datetime.strftime(yesterday, '%Y-%m-%d')
        #
        #s3_key =  manifest_file_prefix + yesterday_date_as_string + manifest_file_suffix 
        #s3_inventory_report_s3_object = client.get_object(Bucket=inventory_report_bucket, Key=s3_key)
        #
        #manifest_json = json.loads(s3_inventory_report_s3_object['Body'].read())
        ##manifest json looks like: {'sourceBucket': 'bmsrd-ngs-data', 'destinationBucket': 'arn:aws:s3:::bmsrd-aws-s3-inventory', 'version': '2016-11-30', 'creationTimestamp': '1709168400000', 'fileFormat': 'Parquet', 'fileSchema': 'message s3.inventory {  required binary bucket (STRING);  required binary key (STRING);  optional int64 size;  optional int64 last_modified_date (TIMESTAMP(MILLIS,true));  optional binary storage_class (STRING);  optional binary intelligent_tiering_access_tier (STRING);}', 'files': [{'key': 'bmsrd-ngs-data/bmsrd-ngs-data-daily/data/a37fb450-3d2d-47c8-944a-fd91b764ef64.parquet', 'size': 48814778, 'MD5checksum': '38f423aa6cfecba5b272c7fccad72070'}, {'key': 'bmsrd-ngs-data/bmsrd-ngs-data-daily/data/47e6bcb4-47d2-4b95-ac20-aca717c8e27bo.parquet', 'size': 5975699, 'MD5checksum': '5857efad93edb81f3619ae75dc3f2f21'}, ...]}
        #
        #list_processed_runs_pre_status_check = []
        #
        ##iterate over manifest_json.files to retrieve all of the partitioned parquet objects
        #for file_object in manifest_json['files']:
        #    
        #    #for test purposes, overwriting variable and swapping ngs bucket data with test S3 bucket data because NGS bucket does not have any data
        #    #remove continue prior to production to pull data from the S3 inventory report 
        #    return ['NGS/SevenBridges/PAD2_CL-187843_VL.csv']
        #    
        #    #iteratively get parquet object from s3 inventory report bucket
        #    parquet_partition_object = client.get_object(Bucket=inventory_report_bucket, Key=file_object['key'])
        #    
        #    #read parquet as pandas dataframe for faster data processing
        #    parquet_as_df = pd.read_parquet(io.BytesIO(parquet_partition_object['Body'].read()))
        #    
        #    #filter to identify all S3 files in the NGS bucket which meet the file format requirements: structure (s3://bmsrd-ngs-results/P-*/DBTx/*) 
        #    filtered_df_all_dbtx_files = parquet_as_df[parquet_as_df['key'].str.contains('P-') & parquet_as_df['key'].str.contains('/DBTx/') & parquet_as_df['key'].str.contains('.csv')]
        #    
        #    #filter specifically for run files (with naming convention CL-*) - script will start by processing run-by-run
        #    filtered_df_only_runs = filtered_df_all_dbtx_files[filtered_df_all_dbtx_files['key'].str.contains('CL-')]
        #    
        #    #extend the original list of runs
        #    list_processed_runs_pre_status_check.extend(filtered_df_only_runs['key'].tolist())
        #
        #return list_processed_runs_pre_status_check
    except Exception as e:
        logger.error("Error occured in get_runs_from_inventory_report. Error description is - {}".format(str(e)))
    

try:
    #initialize DynamoDB Boto3 environment to make API calls to DynamoDB
    dynamodb = boto3.client('dynamodb')
    
    #configuration stored in secrets manager
    config_json = dpcu.get_config_details(config_s3_bucket, config_s3_filepath)
    #config_json = retrieve_env_variables_from_secrets_manager()
    
    logger.info("Running nightly job with configuration: {} ".format(str(config_json)))
    
    #status = dynamodb_status_check("ngs-poc-table", "test_for_ngs/Example_NGS_Files/PAD2_ER_Metadata.xlsx")
    status = dynamodb_status_check(config_json['status_checking_dynamodb_table'], config_json['er_metadata_data_product_s3_path'])
    
    logger.info("status is : {} ".format(str(status)))
    
    #get inventory report from RDGenomics S3 to determine whether any new runs have been added. A "run" is defined by a new NGS results file, such as "PAD2_CL-123_VL"
    #function returns a list of S3 paths where all PAD2 NGS results files are located
    #  
    #def get_runs_from_inventory_report(inventory_report_bucket, manifest_file_prefix, manifest_file_suffix): 
    #list_processed_runs_pre_status_check = get_runs_from_inventory_report(config_json['s3_inventory_bucket'], config_json['s3_inventory_report_manifest_file_prefix'], config_json['s3_inventory_report_manifest_file_suffix'])
    
    list_processed_runs_pre_status_check = get_runs_from_inventory_report()
    
    logger.info("list_processed_runs_pre_status_check is - {} ".format(list_processed_runs_pre_status_check))
    
    list_runs_missing_from_data_product = list_processed_runs_pre_status_check
    
    logger.info("list_runs_missing_from_data_product is - {} ".format(list_runs_missing_from_data_product))
    
    list_runs_missing_from_data_product = []
    
    #for each NGS run, determine if that run has been processed by a status check with DynamoDB. 
    for run in list_processed_runs_pre_status_check:
        logger.info("Checking status of run: {} ".format(run))
        
        #if the S3 path is not in DynamoDB, add it to the list of  
        if not dynamodb_status_check(config_json['status_checking_dynamodb_table'], run):
            list_runs_missing_from_data_product.append(run)
    
    #If any NGS results data is missing from the data product, then begin processing the new data into the NGS results data product
    if len(list_runs_missing_from_data_product) > 0:
        logger.info("Found the following NGS results datasets to process: {} ".format(str(list_runs_missing_from_data_product)))
        
        #initialize the data product as a pandas dataframe in order to add new data iteratively
        ngs_results_data_product_df = initialize_data_product(config_json['ngs_results_data_product_s3_bucket'], config_json['ngs_results_data_product_s3_path'])
        
        for ngs_results_s3_key in list_runs_missing_from_data_product:
            #get new NGS data file from S3
            new_ngs_dataset_df = get_data_from_s3(config_json['ngs_results_data_product_s3_bucket'], ngs_results_s3_key)
            
            #transform NGS data into long-form
            transformed_df = transform_ngs_results_data(ngs_results_s3_key, new_ngs_dataset_df)
            
            #concatenate new long-form ngs results data to the existing data product
            ngs_results_data_product_df = pd.concat([ngs_results_data_product_df, transformed_df])
            
            #add row to status table indicating new run has been processed
            dynamodb.put_item(TableName=config_json['status_checking_dynamodb_table'], Item={'filename':{'S':ngs_results_s3_key}})
        
        
        #after all new NGS files have been processed, uploS the data product into S3. This will create a new version of the S3 file.
        s3_location_ngs_results = config_json['s3_location_ngs_results']
        ngs_publish_database = config_json['ngs_publish_database']
        ngs_results_tablename = config_json['ngs_results_tablename']
        dttype_ngs_results = config_json['dttype_ngs_results']
        upload_final_data_product(ngs_results_data_product_df, config_json['ngs_results_data_product_s3_bucket'], config_json['ngs_results_data_product_s3_path'],s3_location_ngs_results,ngs_publish_database,ngs_results_tablename, dttype_ngs_results)
        
        #After processing all NGS results data, determine if the related ER and Sample metadata have already been processed into their respective data products, or still need to be processed
        
        #processing these data products has the same steps as NGS results data, except there is no transformation step so it is commented out
        er_metadata_data_product_df = initialize_data_product(config_json['ngs_results_data_product_s3_bucket'], config_json['er_metadata_data_product_s3_path'])
        
        for ngs_results_s3_key in list_runs_missing_from_data_product:
            #derive the path of the ER metadata file relative to the ngs results data file
            er_metadata_file_s3_location = ngs_results_s3_key.split('/')[0] + '/' + ngs_results_s3_key.split('/')[1] + '/PAD2_ER_Metadata.xlsx'
            
            #check if the ER metadata file corresponding to the NGS run has already been processed or not
            er_metadata_processed_bool = dynamodb_status_check(config_json['status_checking_dynamodb_table'],er_metadata_file_s3_location)
            
            logger.info("er_metadata_file_s3_location is - {}".format(er_metadata_file_s3_location))
            #er_metadata_processed_bool = False
            #if not processed, process the metadata file 
            if er_metadata_processed_bool == False:
                #er metadata files are excel, not csv, so use the get_data_from_s3_excel function instead. 
                new_er_metadata_dataset_df = get_data_from_s3_excel(config_json['ngs_results_data_product_s3_bucket'], er_metadata_file_s3_location)
                # Note that there is no transformation step here 
                
                #concatenate ER metadata data to the existing data product as-is
                er_metadata_data_product_df = pd.concat([er_metadata_data_product_df, new_er_metadata_dataset_df])
                
                #add row to status table indicating new ER metadata file has been processed
                dynamodb.put_item(TableName=config_json['status_checking_dynamodb_table'], Item={'filename':{'S':er_metadata_file_s3_location}})
        
        s3_location_er_metadata = config_json['s3_location_er_metadata']
        ngs_publish_database = config_json['ngs_publish_database']
        er_metadata_tablename = config_json['er_metadata_tablename']
        dttype_er_metadata = config_json['dttype_er_metadata']
        
        upload_final_data_product(er_metadata_data_product_df, config_json['ngs_results_data_product_s3_bucket'], config_json['er_metadata_data_product_s3_path'],s3_location_er_metadata,ngs_publish_database,er_metadata_tablename,dttype_er_metadata)
        
        
        sample_metadata_data_product_df = initialize_data_product(config_json['ngs_results_data_product_s3_bucket'], config_json['sample_metadata_product_s3_path'])
        for ngs_results_s3_key in list_runs_missing_from_data_product:
            sample_metadata_s3_location = ngs_results_s3_key.split('/')[0] + '/' + ngs_results_s3_key.split('/')[1] + '/PAD2_Sample_Metadata.csv'
            #sample_metadata_processed_bool = dynamodb_status_check(config_json['status_checking_dynamodb_table'],sample_metadata_s3_location)
            
            sample_metadata_processed_bool = False
            if sample_metadata_processed_bool == False:
                new_sample_metadata_dataset_df = get_data_from_s3(config_json['ngs_results_data_product_s3_bucket'], sample_metadata_s3_location)
                
                # Note that there is no transformation step here 
                #concatenate sample metadata data to the existing data product as-is
                final_sample_metadata_df = pd.concat([sample_metadata_data_product_df, new_sample_metadata_dataset_df])
                
                #add row to status table indicating new sample metadata file has been processed
                dynamodb.put_item(TableName=config_json['status_checking_dynamodb_table'], Item={'filename':{'S':sample_metadata_s3_location}})
            
        s3_location_sample_metadata = config_json['s3_location_sample_metadata']
        ngs_publish_database = config_json['ngs_publish_database']
        sample_metadata_tablename = config_json['sample_metadata_tablename']
        dttype_sample_metadata = config_json['dttype_sample_metadata']
        
        upload_final_data_product(final_sample_metadata_df, config_json['ngs_results_data_product_s3_bucket'], config_json['sample_metadata_product_s3_path'],s3_location_sample_metadata,ngs_publish_database,sample_metadata_tablename,dttype_sample_metadata)
            
    else:
        logger.info("No files to process - terminating Glue script")
    
    dpcu.trigger_notification(jobName, logStreamName, 'Code execution Completed for ' + jobName, infoEventType, notification_flag, solution_name, sqs_trigger_notification)
except Exception as e:
    logger.info("NGS Publish job failed. Error description is - {}".format(str(e)))
    dpcu.trigger_notification(jobName, errorlogStreamName, 'Exception: Error occured in while executing job, Error is - ' + str(e), errorEventType, notification_flag, solution_name, sqs_trigger_notification)
    raise e
	
## Job Execution Ended..!!
glueJob.commit()

