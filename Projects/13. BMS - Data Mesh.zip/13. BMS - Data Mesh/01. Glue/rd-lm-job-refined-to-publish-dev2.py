from os import replace
import traceback
import sys
from awsglue.transforms import *                                                                                           
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
from datetime import datetime, timedelta
import awswrangler as wr
import logging
import re
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pyspark.sql.functions as F
import pandas as pd
from threading import Thread
import pytz
ist = pytz.timezone('Asia/Kolkata')

logger = logging.getLogger()
args = getResolvedOptions(sys.argv, ["JOB_NAME"])
job_args = getResolvedOptions(sys.argv,["config_s3_filepath","config_s3_bucket","data_product_sqlkey_list","utility_s3_filepath","sqs_trigger_notification","solution_name","notification_flag", "iceberg_warehouse_path", "source_name", "publish_s3_temp_path"])

jobName = args["JOB_NAME"]
jobRunId = args['JOB_RUN_ID']
notification_flag = job_args["notification_flag"]
solution_name = job_args["solution_name"]
sqs_trigger_notification =job_args["sqs_trigger_notification"]
utility_s3_filepath = job_args["utility_s3_filepath"]
source_name = job_args["source_name"]
publish_s3_temp_path = job_args["publish_s3_temp_path"]
iceberg_warehouse_path = job_args["iceberg_warehouse_path"]

logStreamName = "CloudWatch > Log groups > /aws-glue/jobs/output/" + jobRunId
errorlogStreamName = "CloudWatch > Log groups > /aws-glue/jobs/error/" + jobRunId

infoEventType = "INFO"
errorEventType = "ERROR"

conf = SparkConf()
conf.set("spark.sql.defaultCatalog", "iceberg_catalog")
conf.set("spark.sql.catalog.iceberg_catalog.warehouse", iceberg_warehouse_path)
conf.set("spark.sql.catalog.iceberg_catalog", "org.apache.iceberg.spark.SparkCatalog")
conf.set("spark.sql.catalog.iceberg_catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")
conf.set("spark.sql.catalog.iceberg_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
conf.set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
conf.set("spark.sql.iceberg.handle-timestamp-without-timezone","true")
conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "LEGACY")

sc = SparkContext(conf=conf)
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sparkSession = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "LEGACY") 
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED") 

# Add reference files
spark.sparkContext.addPyFile(utility_s3_filepath)
#importing the utility file
import gd_dp_common_utility as dpcu

config_object_key = job_args["config_s3_filepath"]
bucket = job_args["config_s3_bucket"]
data_product_sqlkey_list = job_args["data_product_sqlkey_list"]

s3 = boto3.client('s3')
secret_client = boto3.client('secretsmanager')

is_failed=False
message_dict = {}
failed_tables=[]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

def athena_query(database_name, sql_query, target_schema, target_table):
    df_results = wr.athena.read_sql_query(sql=sql_query, database=database_name, ctas_approach=False, s3_output=publish_s3_temp_path)
    df_results = df_results.astype(object).where(pd.notnull(df_results),"")
    df_results = df_results.astype(str)
    df_results = df_results.astype(str).replace("NaN","")
    #df_results = df_results.na.fill(None)
    
    logger.info("Schema of df_results is - {}".format(df_results.info()))
    logger.info("Count of df_results is - {}".format(len(df_results)))
    
    #Creating empty spark dataframe without any columns 
    df_raw = sparkSession.createDataFrame([], StructType([]))
    for key, value in target_schema.items():
        df_raw = df_raw.withColumn(key, lit(None).cast(StringType()))
        
    #Fetch Schema from Spark dataframe and converting into Spark dataframe supported dictionary.
    schema_json = df_raw.schema.json()
    schema_dict = json.loads(schema_json)
    default_schema = StructType.fromJson(json.loads(json.dumps(schema_dict)))    
    
    #Loading Pandas dataframe into Spark dataframe with Schema
    df_query_output = sparkSession.createDataFrame(df_results, schema=default_schema)
    logger.info("Before Typecast : Schema of df_query_output columns is - {}".format(df_query_output.printSchema()))
    
    logger.info("Typecasting process started for Table - {}".format(target_table))
    
    #Typecasting of spark dataframe columns based on target_schema
    for key, value in target_schema.items():
        logger.info("Key is - {}".format(key))
        logger.info("Value is - {}".format(value))
        if(value.lower() == "string"):
            logger.info("string")
            df_query_output = df_query_output.withColumn(key,col(key).cast(StringType()))
        elif(value.lower() == "int"):
            logger.info("int")
            df_query_output = df_query_output.withColumn(key,col(key).cast(IntegerType()))
        elif(value.lower() == "float"):
            logger.info("float")
            df_query_output = df_query_output.withColumn(key,col(key).cast(FloatType()))
        elif(value.lower() == "double"):
            logger.info("double")
            df_query_output = df_query_output.withColumn(key,col(key).cast(DoubleType()))
        elif(value.lower() == "date"):
            logger.info("date")
            df_query_output = df_query_output.withColumn(key,col(key).cast(DateType()))
        elif("decimal" in value.lower()):
            logger.info("decimal")
            df_query_output = df_query_output.withColumn(key,col(key).cast(value))
        elif(value.lower() == "datetime"):
            logger.info("datetime")
            df_query_output = df_query_output.withColumn(key,to_timestamp(col(key),'yyyy-MM-dd HH:mm:ss'))
        elif(value.lower() == "timestamp"):
            logger.info("timstamp")
            df_query_output = df_query_output.withColumn(key,col(key).cast(TimestampType()))
        else:
            logger.info("else - string")
            df_query_output = df_query_output.withColumn(key,col(key).cast(StringType()))
            
    logger.info("Typecasting process Completed for Table - {}".format(target_table))
    
    df_query_output = df_query_output.select([when(col(column)=="<NA>",None).otherwise(col(column)).alias(column) for column in df_query_output.columns])
    #df_query_output = df_query_output.select([F.when(F.isnan(F.col(column)),None).otherwise(F.col(column)).alias(column) for column in df_query_output.columns])
    #df = df.withColumn(column,F.when(F.isnan(F.col(column)),None).otherwise(F.col(column)))
    logger.info("After Typecast : Schema df_query_output is - {}".format(df_query_output.printSchema()))
    logger.info("Count of df_query_output is - {}".format(df_query_output.count()))

    return df_query_output


        
def write_iceberg_table_using_spark(sparkSession, df_curated, iceberg_database, iceberg_table, iceberg_path):
    try:
        df_curated.createOrReplaceTempView("curated_data_" + iceberg_table)
        
        if wr.catalog.does_table_exist(database=iceberg_database, table=iceberg_table):

            logger.info("**** Table {} exists !!! Updating Delete flag as Y ".format(iceberg_table))
            sql_stmnt = f"""
                    UPDATE {iceberg_database}.{iceberg_table}
                    SET delete_flag='Y'"""
            
            logger.info("sql_stmnt is - {}".format(sql_stmnt))
            sparkSession.sql(sql_stmnt)
            
            
            sql_stmnt = f"""
                    INSERT INTO {iceberg_database}.{iceberg_table}
                    SELECT a.*,'N' as delete_flag FROM curated_data_{iceberg_table} a"""

            logger.info("sql_stmnt is - {}".format(sql_stmnt))
            sparkSession.sql(sql_stmnt)                    
            
            logger.info("**** Deleting records from Table {} which has Delete flag set as Y ".format(iceberg_table))
            sql_stmnt = f"""
                    DELETE FROM {iceberg_database}.{iceberg_table}
                    WHERE delete_flag='Y'"""
            
            logger.info("sql_stmnt is - {}".format(sql_stmnt))
            sparkSession.sql(sql_stmnt)
        else:
        
            logger.info("**** Table {} does not exists !!! Creating table with Delete flag as NULL ".format(iceberg_table))
            sql_stmnt = f"""
                CREATE TABLE {iceberg_database}.{iceberg_table}
                USING iceberg
                LOCATION '{iceberg_path}'
                AS SELECT a.*,'N' as delete_flag FROM curated_data_{iceberg_table} a"""
                
            logger.info("sql_stmnt is - {}".format(sql_stmnt))
            sparkSession.sql(sql_stmnt)
            
    except Exception as e:
        logger.error("Exception: Error occured in write_into_iceberg_table method, Error is - {}".format(str(e)))
        raise e 
        
def drop_glue_table_using_spark(sparkSession, databasename, tablename):
    logger.info(f"target_database:{databasename}")
    logger.info(f"target_table:{tablename}")
    sql_stmnt = "DROP TABLE IF EXISTS " + databasename + "." + tablename
    sparkSession.sql(sql_stmnt)

def publish_data_product(data_product_sqlkey):

    try:
    
        logger.info("Processing data product - {} has been started..!!".format(data_product_sqlkey))
            
        # Reading values from config file for particular Data product
        table_name = data_product_sqlkey
        dp_sql_s3_uri = read_config_data[data_product_sqlkey]['data_product_sql']
        target_write_mode = read_config_data[data_product_sqlkey]['write_mode']
        source_database = read_config_data[data_product_sqlkey]['source_database']
        target_database = read_config_data[data_product_sqlkey]['target_database']
        target_table = read_config_data[data_product_sqlkey]['target_table']
        target_s3_location = read_config_data[data_product_sqlkey]['target_s3_location']
        target_s3_temp_location = read_config_data[data_product_sqlkey]['target_s3_temp_location']
        target_iceberg_schema = read_config_data[data_product_sqlkey]['target_iceberg_schema']
        
        
        dp_sql_s3_bucket, dp_sql_s3_key = dp_sql_s3_uri.replace("s3://", "").split("/", 1)
        
        logger.info("dp_sql_s3_uri value is - {}".format(dp_sql_s3_uri))
        logger.info("dp_sql_s3_bucket value is - {}".format(dp_sql_s3_bucket))
        logger.info("dp_sql_s3_key value is - {}".format(dp_sql_s3_key))
        logger.info("target_write_mode value is - {}".format(target_write_mode))
        logger.info("source_database value is - {}".format(source_database))
        logger.info("target_database value is - {}".format(target_database))
        logger.info("target_table value is - {}".format(target_table))
        logger.info("target_s3_location value is - {}".format(target_s3_location))
        logger.info("target_s3_temp_location value is - {}".format(target_s3_temp_location))
        
        # Getting SQL query from S3 bucket for the Data product
        dp_sql_query=s3.get_object(Bucket=dp_sql_s3_bucket, Key=dp_sql_s3_key)["Body"].read().decode()
        logger.info("SQL Query is - {}".format(dp_sql_query))
        
        logger.info('***** Running Data product SQL Query in Athena *************')
        df_output_raw = athena_query(source_database,dp_sql_query, target_iceberg_schema, target_table)        
        logger.info('***** Completed running SQL Query *************')
        
        # Adding Source column to the query output dataframe
        df_output = df_output_raw.withColumn("source_name", lit(source_name))        
        
        #if target_write_mode == 'overwrite':
        #    drop_glue_table_using_spark(sparkSession, target_database, target_table)
        #    logger.info("Data product table - {} is dropped..!!".format(data_product_sqlkey))
        
        # Write Spark dataframe data into Publish Iceberg Table 
        write_iceberg_table_using_spark(sparkSession,df_output,target_database, target_table, target_s3_location) 
        logger.info('***** Completed *************')
        
        logger.info("Processing data product - {} has been completed..!!".format(data_product_sqlkey))  

        
        dpcu.message_dict[table_name]["ingestion_status"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": ingestion for {table_name} completed"
       

    except Exception as e:
        global is_failed
        is_failed=True
        global failed_tables
        failed_tables.append(table_name)
        logger.error("******************************Error************************************")
        logger.error(e,exc_info=True)
        
# Read config json for the data product passed as glue parameter
read_config_data=dpcu.get_config_details(bucket,config_object_key)
logger.info(read_config_data)
logger.info(data_product_sqlkey_list)

try:
    logger.info("LM - Publish job has been started..!!")
    
    data_product_sqlkey_list1 = json.loads(data_product_sqlkey_list)
    
    THREADS = 5
    # list of table splitted based on the thread count
    splits = [data_product_sqlkey_list1[x:x+THREADS] for x in range(0, len(data_product_sqlkey_list1), THREADS)]
    logger.info(splits)
    
    for k in splits:
        logger.info(k)
        threads=[]
        for TABLE_NAME in k:
            dpcu.message_dict[TABLE_NAME] ={}
            logger.info(TABLE_NAME)
            

            process=Thread(target=publish_data_product,args=[TABLE_NAME])
            process.start()
            threads.append(process)
               
        for process in threads:
            process.join()
    
    if is_failed == True:        
        raise Exception('Failed on some tables.. Please check log for more details')
        
    logger.info("******FINAL STATUS MESSAGE******")
    
    for table, statuses in dpcu.message_dict.items():
        logger.info(f"Table: {table}")
        for status_name, status_value in statuses.items():
            logger.info(f"{status_name}: {status_value}")    
    
    #Trigger Success notifications 
    dpcu.trigger_notification(jobName, logStreamName, 'Genedata data products have been refreshed in publish layer', infoEventType, notification_flag, solution_name, sqs_trigger_notification)
    logger.info("LM - Publish job has been completed..!!")
except Exception as e:
    traceback.print_exception(*sys.exc_info())
    # Trigger Failed notifications
    dpcu.trigger_notification(jobName, errorlogStreamName, 'Code execution failed for ' + jobName + ". Error Description is " + str(e), errorEventType, notification_flag, solution_name, sqs_trigger_notification)  
    raise e
    
job.commit()
