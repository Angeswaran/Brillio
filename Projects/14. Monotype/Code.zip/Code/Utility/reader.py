import quality_check
import logger

def reader(spark,source):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        audit_df= spark.sql("select 'inside reader' as status ,current_timestamp as time")
        audit_df.write.mode("append").insertInto("data_enrichment_layer.status_log") 

        if(source["type"] == 'mysql'):
            df= read_mysql(spark,source)
        elif(source["type"] == 'sqlserver'):
            df= read_sqlserver(spark,source)
        elif(source["type"] == 'mongodb'):
            df= read_mongodb(spark)
        elif(source["type"] == 'redshift'):
            df= read_redshift(spark)
        elif(source["type"] == 'parquet'):
            df= read_parquet(spark)
        elif(source["type"] == 'gluecatalog'):
            df= read_gluecatalog(spark)      
        else:
            df= print("invalid source")    
            return spark.sql("select null as result")
    
        if (source.keys().contains("null_check") and  source["null_check"] != "") or (source.keys().contains("custom_qc_check") and  source["custom_qc_check"] != ""):
            quality_check.quality_check(spark,df,source)   
        else:
            return df
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e) 
    

def form_dynamic_where_clause(columns,condition):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        where_clause = ""
        where_condition = ""
        if condition == "null":
            where_condition = "is null"
        else:
            where_condition = " > '{}'".format(condition)

        if columns is not None and columns != "":
            cnt = 1
            for col_name in columns.split(","):
                if cnt > 1:
                    where_clause +="or " + col_name + " {} ".format(where_condition)
                else:
                    where_clause += col_name + " > {} ".format(where_condition)
                    cnt+=1
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)
    return where_clause
    
def form_dynamic_query(databasename,tablename,select_column,cdc_column):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        query = "select {select_column} from {databasename}.{tablename}".format(select_column,databasename,tablename)
        where_clause = form_dynamic_where_clause(cdc_column)
        query += " where "+ where_clause
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)
    return query


def read_mysql(spark,source):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        jdbc_url = "jdbc:mysql://{servername}:{port}/{databasename}".format(**source)
        username = "dbSteph" # fetch information from secrets
        password = "Ll607257415833" # defetch information from secrets
        databasename = source["databasename"]
        Table_name = source["tablename"]
        select_column = source["tablename"]
        cdc_column = source["cdc_column"]
        query = form_dynamic_query(databasename,Table_name,select_column,cdc_column)
        
        # spark.sql("select '{}' as status ,current_timestamp as time".format(query)).write.mode("append").insertInto("data_enrichment_layer.status_log") 
        df = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("query", query) \
        .option("user", username) \
        .option("password", password) \
        .load()

        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)
    
    return df

def read_sqlserver(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        print("")
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)

def read_mongodb(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))

        columns = ["name","resourceId","familyId","familyName","variationId","subtype","source","actionName","customerId","userId","createdOn"]

        username = "readuser"
        password = "MTd50PzFTX7JI6yB"
        host = "mtfmongoanalytics.caqct.mongodb.net"
        database = "mosaic-report-db"
        collection = "fonts"
        mongodb_uri = f"mongodb+srv://{username}:{password}@{host}"
        query = { "field": {
         "$in": columns,
         "$gt": "createdOn"
          }
        }

        df = spark.read.format("mongo") \
        .option("uri", mongodb_uri) \
        .option("database", database) \
        .option("collection", collection) \
        .option("pipeline", "[{{ $match: {} }}]".format(query)) \
        .load()
    
        return df

        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)

def read_redshift(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        redshift_url = "jdbc:redshift://customer-analytics-data-1.ci9todflq6tn.us-east-1.redshift.amazonaws.com/heap"
    
        redshift_properties = {
            "user": "redshift_brillio",
            "password": "cwdOeefjri4gPZm",
            "driver": "com.amazon.redshift.jdbc42.Driver"
        }
        
        df = spark.read \
            .format("jdbc") \
            .option("url", redshift_url) \
            .option("dbtable", "mosaic_production.sessions") \
            .option("user", redshift_properties["user"]) \
            .option("password", redshift_properties["password"]) \
            .option("driver", redshift_properties["driver"]) \
            .load()
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)
    return df 


def snowflake(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        print("")
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)    

def read_parquet(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        print("")
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)

def read_gluecatalog(spark):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        print("")
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)

    

    