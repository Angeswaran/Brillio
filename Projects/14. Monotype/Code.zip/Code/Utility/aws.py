import boto3
import logger

def read_file_from_s3(spark,bucket_name,file_key):
    spark.sql("select 'inside read_file_from_s3' as status ,current_timestamp as time").write.mode("append").insertInto("data_enrichment_layer.status_log")   
    __method_name = logger.current_function_name()
    try:
        logger.info('Method {} has started'.format(__method_name))
        s3 = boto3.client('s3')
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        content = response['Body'].read().decode('utf-8')
        logger.info('Method {} has Completed'.format(__method_name))
        return content
    except Exception as e:
        # spark.sql("select '{}' as status ,current_timestamp as time".format(e)).write.mode("append").insertInto("data_enrichment_layer.status_log") 
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e) 
        return None