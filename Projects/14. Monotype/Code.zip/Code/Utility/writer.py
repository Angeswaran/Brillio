import logger

def write_into_s3(df,spark,location,write_mode,repartition_no):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        spark.sql("select 'write_into_s3' as status ,current_timestamp as time").write.mode("append").insertInto("data_enrichment_layer.status_log") 
        df.write.mode(write_mode).parquet(location)
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e)

def write_into_table(dataframe,spark,dbname,table_name,write_mode,repartition_no,partitions=None):
    __method_name = logger.current_function_name()
    try: 
        logger.info('Method {} has started'.format(__method_name))
        if(spark.catalog.tableExists(dbname+"."+table_name)):
            dataframe.write.mode(write_mode).insertInto(dbname+"."+table_name)
        else:
            if(partitions == None):
                dataframe.write.mode(write_mode).saveAsTable(dbname+"."+table_name)
            else:
                dataframe.write.mode(write_mode).partitionBy(partitions).saveAsTable(dbname+"."+table_name)
        logger.info('Method {} has Completed'.format(__method_name))
    except Exception as e:
        logger.error('Method {} has Failed with exception'.format(__method_name))
        raise Exception(e) 