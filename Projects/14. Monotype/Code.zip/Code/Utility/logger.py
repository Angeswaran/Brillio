import sys

def current_function_name():
    frame = sys._getframe(1)
    return frame.f_code.co_name