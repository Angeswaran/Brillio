import sys, boto3, datetime, json, time
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
import datetime
import logging
from datetime import datetime, timedelta, date 
from threading import Thread
import time
import pytz
#ist = pytz.timezone('Asia/Kolkata')
#from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format, lit, current_timestamp, current_date, date_sub
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType
from email.utils import formataddr
from smtplib import SMTP_SSL, SMTPException
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import time
import requests
from pyspark.sql import functions as F

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "notification_flag", "thread_count", "multithreading_flag", "common_config_s3_bucket", "common_config_s3_filepath"])                        

jobName = args['JOB_NAME']
jobRunId = args['JOB_RUN_ID']
config_s3_bucket = args['config_s3_bucket']
config_s3_filepath = args['config_s3_filepath']
utility_s3_filepath = args['utility_s3_filepath']
notification_flag = args['notification_flag']
thread_count = int(args['thread_count'])
multithreading_flag = args['multithreading_flag']
common_config_s3_bucket = args['common_config_s3_bucket']
common_config_s3_filepath = args['common_config_s3_filepath']

# Initializing the SparkContext, GlueContext and SQL Context
conf = SparkConf()
sparkContext = SparkContext(conf=conf)
glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInWrite","LEGACY")
sparkSession.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")

# Import custom common functions from utility
import lm_common_utility as lmcu

config_details = lmcu.get_config_details(config_s3_bucket, config_s3_filepath)

sparkSession.conf.set("spark.sql.adaptive.enabled", "true")

s3_client = boto3.client('s3')

info_event_type = "INFO"
error_event_type = "ERROR"

try:
    schema = build_base_validation()
    data = []
    validation_df = sparkSession.createDataFrame(data, schema)

    current_load_date = (datetime.now()).strftime('%Y-%m-%d 00:00:00')
    #current_load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    last_load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')

    # Control table RDS credentials    
    for data_source in config_details["data_sources"]:
        if(ds_platform_mysql == "platform_mysql" and data_source["data_source"]=="platform_mysql"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                secret_name = database["secret_name"]
                sectrets_data = lmcu.get_secret(secret_name)
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    logger.info("sectrets_data is - {}".format(sectrets_data))
                    logger.info("secret_name is - {}".format(secret_name))
                    logger.info("table_details is - {}".format(table_details))
                    #process_pf_mysql_data(sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, last_load_date, current_load_date)
                    process=Thread(target=process_pf_mysql_data,args=[sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()                    
                    threads.append(process)
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for My SQL data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for My SQL data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_snowflake == "sf_snowflake" and data_source["data_source"]== "sf_snowflake"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    process=Thread(target=process_snowflake_data,args=[sparkSession,table_details,database,data_source,last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()
                    threads.append(process)                    
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"])) 
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Snowflake data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Snowflake data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_heap_redshift == "heap_redshift" and data_source["data_source"]== "heap_redshift"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                secret_name = database["secret_name"]
                sectrets_data = lmcu.get_secret(secret_name)
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    process=Thread(target=process_heap_redshift_data,args=[sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()
                    threads.append(process)                    
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)        
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_usage_s3 == "usagedb_s3" and data_source["data_source"]== "usagedb_s3"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            threads=[]
            output_df_list = []
            for table_details in data_source["table_details"]:
                logger.info("table_details is -{}".format(table_details))
                logger.info("Type table_details is -{}".format(type(table_details)))
                if(table_details["is_hold"] == "Y"):
                    continue
                process=Thread(target=process_usage_db,args=[sparkSession, table_details, output_df_list, success_tables_list, failed_tables_list, jobName])
                process.start()
                threads.append(process)                    
            for process in threads:
                process.join()
            data_validation_df = data_validation_df + output_df_list
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"            
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_pageview_daily_api == "pageview_daily_api" and data_source["data_source"]== "pageview_daily_api"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []           
            output_df_list = []
            for api_details in data_source["api_details"]:
                logger.info("api_details is -{}".format(api_details))
                logger.info("Type api_details is -{}".format(type(api_details)))
                sectrets_data = lmcu.get_secret(str(data_source["secret_name"]))
                if(api_details["is_hold"] == "Y"):
                    continue
                load_start_date = datetime.strptime('2024-05-12', '%Y-%m-%d')
                load_end_date = datetime.strptime('2024-05-13', '%Y-%m-%d')
                process_pageview_api_data(sparkSession, load_start_date, load_end_date, api_details, sectrets_data, logger, output_df_list, success_tables_list, failed_tables_list, jobName)
            data_validation_df = data_validation_df + output_df_list
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        else:
            logger.info("data_source is not properly defined")
                    
except Exception as e:
    #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", error_event_type, "The Ingestion Glue job has been failed. Error Description is - {}".format(str(e)), logger)
    logger.info("Error occured in main method. Error - {}".format(str(e)))
    raise Exception(e)

logger.info("LM - Ingestion Glue has been completed..!!")

## Job Execution Ended..!!
glueJob.commit()