import sys, boto3, datetime, json, time
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
import datetime
import logging
from datetime import datetime  
from threading import Thread
import time
import pytz
ist = pytz.timezone('Asia/Kolkata')

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "notification_flag", "thread_count", "multithreading_flag"])                        

jobName = args['JOB_NAME']
jobRunId = args['JOB_RUN_ID']
config_s3_bucket = args['config_s3_bucket']
config_s3_filepath = args['config_s3_filepath']
utility_s3_filepath = args['utility_s3_filepath']
sqs_trigger_notification = args['sqs_trigger_notification']
notification_flag = args['notification_flag']
solution_name = args['solution_name']
iceberg_warehouse_path = args['iceberg_warehouse_path']
thread_count = int(args['thread_count'])
multithreading_flag = args['multithreading_flag']
raw_s3_path = args['raw_s3_path']

logStreamName = "CloudWatch > Log groups > /aws-glue/jobs/output/" + jobRunId
errorlogStreamName = "CloudWatch > Log groups > /aws-glue/jobs/error/" + jobRunId

infoEventType = "INFO"
errorEventType = "ERROR"

# Configuration for Iceberg settings
conf = SparkConf()
conf.set("spark.sql.defaultCatalog", "iceberg_catalog")
conf.set("spark.sql.catalog.iceberg_catalog.warehouse", iceberg_warehouse_path)
conf.set("spark.sql.catalog.iceberg_catalog", "org.apache.iceberg.spark.SparkCatalog")
conf.set("spark.sql.catalog.iceberg_catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")
conf.set("spark.sql.catalog.iceberg_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
conf.set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
conf.set("spark.sql.iceberg.handle-timestamp-without-timezone","true")
conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "LEGACY")

is_failed = False
failed_tables=[]

# Initializing the SparkContext, GlueContext and SQL Context
sparkContext = SparkContext(conf=conf)
glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

# Import custom common functions from utility
import gd_dp_common_utility as dpcu

# Creating athena client for accessing athena tables
athena_client = boto3.client('athena')

def read_table_data_using_glue_catalog(glueContext, table_name, raw_s3_path):
    dynamic_df_raw = glueContext.create_dynamic_frame_from_options(
        connection_type="s3",
        connection_options={"paths": [raw_s3_path + table_name.upper() + "/"],
            "recurse": True,
        },
        format="parquet",
    )
    df_raw = dynamic_df_raw.toDF()
    return df_raw
    
### Job Execution started..!!
logger.info("jobName is - {}".format(jobName))
config_details = dpcu.get_config_details(config_s3_bucket, config_s3_filepath)
message_dict = {}

# Main method to Execute cleansing process 
def execute_cleansing_write_to_refined_iceberg_table(table_name, table_details):
    try:
        logger.info("Refined process started for the Table - {}".format(table_name))
        
        # Reading configuration data from Config file for particular table
        raw_database_name = table_details['raw_database_name']
        raw_table_name = table_details['raw_table_name']
        refine_database_name = table_details['refine_database_name']
        refine_table_name = table_details['refine_table_name']
        refine_table_location = table_details['refine_table_location']       
            
        logger.info("raw_database_name is - {}".format(raw_database_name))
        logger.info("raw_table_name is - {}".format(raw_table_name))
        logger.info("refine_database_name is - {}".format(refine_database_name))
        logger.info("refine_table_name is - {}".format(refine_table_name))
        logger.info("refine_table_location is - {}".format(refine_table_location))
        
        # Read data from Raw table 
        df_raw = read_table_data_using_glue_catalog(glueContext, raw_table_name, raw_s3_path)
        message_dict[table_name]["Read status:"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": {raw_table_name} table has been read from {raw_database_name} DB"
        message_dict[table_name][f"Schema - {table_name} :"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": {df_raw.printSchema()} "
        message_dict[table_name][f"Count - {table_name} :"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": {df_raw.count()} "
        
        # Delete Existing data from refined table
        dpcu.drop_glue_table_using_spark(sparkSession, refine_database_name, refine_table_name)
        message_dict[table_name]["***drop status:"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": {refine_table_name} table has been dropped from {refine_database_name} DB"
        
        ##Write Curated data into Iceberg table of refined layer
        dpcu.write_iceberg_table_using_spark(sparkSession, df_raw, refine_database_name, refine_table_name, refine_table_location)
        message_dict[table_name]["***Iceberg write status:"] = datetime.now(ist).strftime('%d/%m/%Y %H:%M:%S')+f": {refine_table_name} table has been written in {refine_database_name} DB"
    except Exception as e: 
        logger.info("Errored in execute_cleansing_write_to_refined_iceberg_table for Table - {}. Error Description is - : {}".format(table_name, str(e)))
        global is_failed
        is_failed=True
        global failed_tables
        #global failed_tables_message
        failed_tables.append(table_name)

# Main steps of refined process starting here. 
try:    
    table_list = [item for item in config_details.keys()]
    logger.info("table_list are - {}".format(table_list))
    
    if(multithreading_flag.upper() == "TRUE"):
        THREADS = thread_count
        splits = [table_list[x:x+THREADS] for x in range(0, len(table_list), THREADS)]
        logger.info("table_list are - {}".format(table_list))
        logger.info(splits)
        
        for k in splits:
            logger.info(k)
            threads=[]
            for TABLE_NAME in k:
                message_dict[TABLE_NAME] ={}
                logger.info(TABLE_NAME)
        
                process=Thread(target=execute_cleansing_write_to_refined_iceberg_table,args=[TABLE_NAME, config_details[TABLE_NAME]])
                process.start()
                threads.append(process)
                
            for process in threads:
                process.join()
    else:
        # Iterating each table in the split.     
        for TABLE_NAME in table_list:
            message_dict[TABLE_NAME] ={}
            logger.info("procssing for the table name is : {}".format(TABLE_NAME))
            execute_cleansing_write_to_refined_iceberg_table(TABLE_NAME, config_details[TABLE_NAME])
            
        if is_failed == True:
            logger.info("failed_tables are : {}".format(failed_tables))      
            raise Exception('Failed on some tables.. Please check log for more details') 
        
    logger.info("******FINAL STATUS MESSAGE******")
    for table, statuses in message_dict.items():
        logger.info(f"Table: {table}")
        for status_name, status_value in statuses.items():
            logger.info(f"{status_name}: {status_value}")   
    dpcu.trigger_notification(jobName, logStreamName, 'Code execution Completed for ' + jobName, infoEventType, notification_flag, solution_name, sqs_trigger_notification)
except Exception as e:
    logger.info("Cleansing job is failed. Error description is - {}".format(str(e)))
    dpcu.trigger_notification(jobName, errorlogStreamName, 'Exception: Error occured in while executing job, Error is - ' + str(e), errorEventType, notification_flag, solution_name, sqs_trigger_notification)
    raise e
    
## Job Execution Ended..!!
glueJob.commit()
