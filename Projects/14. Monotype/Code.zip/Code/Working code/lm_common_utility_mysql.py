import sys, os
import traceback
from io import StringIO, BytesIO 
import json 
import logging
import boto3
from datetime import datetime,timedelta

def get_config_details(config_s3_bucket, config_s3_filepath):
    s3 = boto3.client("s3")    
    content_object = s3.get_object(
        Bucket=config_s3_bucket,
        Key=config_s3_filepath,
    )
    file_content = content_object["Body"].read().decode("utf-8")
    json_content = json.loads(file_content)
    return(json_content)
    
def get_secret(secret_name):
    secret_client = boto3.client('secretsmanager')
    response = secret_client.get_secret_value(SecretId=secret_name)
    secret_value = response['SecretString']
    secret_data = json.loads(secret_value)
    return(secret_data)


def form_dynamic_where_clause(columns,condition):
    try: 
        where_clause = ""
        where_condition = ""
        if condition == "null":
            where_condition = "is null"
        else:
            where_condition = " > '{}'".format(condition)

        if columns is not None and columns != "":
            cnt = 1
            for col_name in columns.split(","):
                if cnt > 1:
                    where_clause +="or " + col_name + " {} ".format(where_condition)
                else:
                    where_clause += col_name + " > {} ".format(where_condition)
                    cnt+=1
    except Exception as e:
        raise Exception(e)
    return where_clause

def form_dynamic_query(databasename,tablename,select_column,cdc_column):
    try: 
        query = "select {0} from {1}.{2}".format(select_column,databasename,tablename)
        #where_clause = form_dynamic_where_clause(cdc_column)
        #query += " where "+ where_clause
    except Exception as e:
        raise Exception(e)
    return query


def read_mysql(spark,source,sectrets_data,db_name):
    try: 
        #jdbc_url = "jdbc:mysql://{servername}:{port}/{databasename}".format(**source)
        #username = "dbSteph" # fetch information from secrets
        #password = "Ll607257415833" # defetch information from secrets
        #databasename = source["databasename"]
        #Table_name = source["tablename"]
        #select_column = source["tablename"]
        #cdc_column = source["cdc_column"]
        
        jdbc_url = "jdbc:mysql://" + sectrets_data["host"] + ":" + sectrets_data["port"] + "/" + db_name
        username = sectrets_data["username"]
        password = sectrets_data["password"]
        databasename = db_name
        Table_name = source["source_table_name"]
        select_column = source["select_column"]
        cdc_column = source["cdc_column"]
        query = form_dynamic_query(databasename,Table_name,select_column,cdc_column)
        
        # spark.sql("select '{}' as status ,current_timestamp as time".format(query)).write.mode("append").insertInto("data_enrichment_layer.status_log") 
        df = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("query", query) \
        .option("user", username) \
        .option("password", password) \
        .load()
        return df
    except Exception as e:
        raise Exception(e)
    
        
def write_into_table(dataframe,spark,dbname,table_name,write_mode,repartition_no,partitions=None):
    try: 
        if(spark.catalog.tableExists(dbname+"."+table_name)):
            dataframe.write.mode(write_mode).insertInto(dbname+"."+table_name)
        else:
            if(partitions == None):
                dataframe.write.mode(write_mode).saveAsTable(dbname+"."+table_name)
            else:
                dataframe.write.mode(write_mode).partitionBy(partitions).saveAsTable(dbname+"."+table_name)
    except Exception as e:
        raise Exception(e) 