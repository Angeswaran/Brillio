import sys, os
import traceback
from io import StringIO, BytesIO 
import json 
import logging
import boto3
from datetime import datetime,timedelta
import time
import pytz
from email.utils import formataddr
from smtplib import SMTP_SSL, SMTPException
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pymysql

s3_client = boto3.client('s3')

"""
Function Name: get_config_details

Description: Method is used for reading config from s3 and return config as json object

Parameters:
config_s3_bucket - Source Bronze bucket name
config_s3_filepath - File path where data resides for particular table.

returns: json_content(json object)

"""  
def get_config_details(config_s3_bucket, config_s3_filepath):
    s3 = boto3.client("s3")    
    content_object = s3.get_object(
        Bucket=config_s3_bucket,
        Key=config_s3_filepath,
    )
    file_content = content_object["Body"].read().decode("utf-8")
    json_content = json.loads(file_content)
    return(json_content)

"""
Function Name: get_secret

Description: Method is used for get secrets based on secrets name and returns credentials in json object

Parameters:
secret_name - name of secrets manager

returns: secret_data(json object)
"""
def get_secret(secret_name):
    secret_client = boto3.client('secretsmanager')
    response = secret_client.get_secret_value(SecretId=secret_name)
    secret_value = response['SecretString']
    secret_data = json.loads(secret_value)
    return(secret_data)

"""
Function Name: build_full_load_query

Description: Method is used to construct sql select query based on the input and returns query as string

Parameters:
databasename - name of the database to fetch data from
tablename - name of the table to fetch data from
select_column - columns to be selected

returns: query(String)
"""  
def build_full_load_query(databasename,tablename,select_column):
    try: 
        query = "select {0} from {1}.{2}".format(select_column,databasename,tablename)
    except Exception as e:
        raise Exception(e)
    return query


"""
Function Name: build_delta_where_condition

Description: Method is used to construct where condition to handle incremental approach based on the input and returns query as string

Parameters:
cdc_column - name of the database to fetch data from
last_load_date - date which incremental load happened last time
current_date - date when till data to be processed

returns: query(String)
"""  
def build_delta_where_condition(cdc_column, last_load_date, current_date):
    try:
        incremental_filter = " WHERE "
        conditions = [] 
        cdc_columns = [] 
        if cdc_column is not None and cdc_column != "":
            cdc_columns = cdc_column.split(",")
            if(len(cdc_columns) > 1):
                condition = f"(coalesce({cdc_column}) > '{last_load_date}' and coalesce({cdc_column}) <= '{current_date}')"
            else:
                condition = f"({cdc_column} > '{last_load_date}' and {cdc_column} <= '{current_date}')"
            incremental_filter += condition
        return incremental_filter
    except Exception as e:
        raise Exception(e)

"""
Function Name: build_delta_query

Description: Method is used to construct sql select query with CDC logic based on the input and returns query as string

Input Parameters:
databasename - name of the database to fetch data from
tablename - name of the table to fetch data from
select_column - columns to be selected
cdc_column - column name based on which CDC logic has to be applied

returns: query(String)
"""  
def build_delta_query(databasename,tablename,select_column,cdc_column,last_load_date, current_date):
    try:
        query = "select {0} from {1}.{2}".format(select_column,databasename,tablename)
        where_clause = build_delta_where_condition(cdc_column,last_load_date,current_date) 
        query += where_clause 
    except Exception as e:
        raise Exception(e)
    return query

"""
Function Name: build_count_query

Description: Method is used to construct sql query to get total count of table based on the input and returns query as string

Parameters:
databasename - name of the database to fetch data from
tablename - name of the table to fetch data from

returns: query(String)
""" 
def build_count_query(databasename,tablename):
    try: 
        query = "select count(*) from {1}.{2}".format(databasename,tablename)        
    except Exception as e:
        raise Exception(e)
    return query


"""
Function Name: read_mysql

Description: Method is used for reading data from Mysql Database and return data as dataframe

Parameters:
spark - active Spark session as the parameter 
source - Source is a dictionary that contains tablename, columns and cdc_columns if any
sectrets_data - Credentials for mySQL Database in json object
db_name - Name of the database
query - query to run in database passed as string
logger - activer logger instance

returns: df(spark dataframe)
""" 
def read_mysql(spark,source,sectrets_data,db_name,query,logger):
    try: 
        jdbc_url = "jdbc:mysql://" + sectrets_data["host"] + ":" + sectrets_data["port"] + "/" + db_name + "?zeroDateTimeBehavior=round"
        username = sectrets_data["username"]
        password = sectrets_data["password"]
        databasename = db_name
        Table_name = source["source_table_name"]
        select_column = source["select_column"]
        cdc_column = source["cdc_column"]
        
        df = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("query", query) \
        .option("user", username) \
        .option("password", password) \
        .load()
        return df
    except Exception as e:
        logger.info("Error occured in read_mysql. Error - {}".format(str(e)))
        raise Exception(e)
        
"""
Function Name: write_into_table

Description: Method is used for writing data into s3 and create glue catalog table based on the input parameters 

Parameters:
spark: active Spark session as the parameter 
df - data in dataframe to write
table_details - Table Details is a dictionary that consist of target database name, table name, partition col, writemode information
logger - activer logger instance
"""        
def write_into_table(spark, df, table_details,logger):
    try: 
        dbname = table_details["target_database_name"]
        table_name = table_details["target_table_name"]
        partitions = None if table_details["target_partition_col"] == "" else table_details["target_partition_col"]
        write_mode = "overwrite" if table_details["target_write_mode"]  == "" else table_details["target_write_mode"]
        
        logger.info("dbname is - {}".format(dbname))
        logger.info("table_name is - {}".format(table_name))
        logger.info("partitions is - {}".format(partitions))
        logger.info("write_mode is - {}".format(write_mode))
        
        if(spark.catalog.tableExists(dbname+"."+table_name)):
            df.coalesce(1).write.mode(write_mode).insertInto(dbname+"."+table_name, path=table_details["target_location"])            
        else:
            if(partitions == None):
                df.coalesce(1).write.mode(write_mode).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])                
            else:
                df.coalesce(1).write.mode(write_mode).partitionBy(partitions).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])                
    except Exception as e:
        logger.info("Failed in write_into_table method. Error is - {}".format(str(e)))
        raise Exception(e)
        
"""
Function Name : send_email

Description   : Method for sending Success and Failure emails to recipient

Parameters    :
sender_email - Email id of the sender
sender_name - Name of the Sender 
recipient_emailids - list of Email ids whom to be notified about Success and failure of the Jobs.
username_smtp_details - User name for the SMTP Server. 
password_smtp_details - Password for the SMTP Server. 
host_name - Host Name for the SMTP Server. 
port_number - Port number for the SMTP Server. 
subject_details - Subject details for the Email.
body_html_details - Body details in HTML format.
convert_df_to_html - Converted dataframe details into HTML format.
"""
def send_email(sender_email, sender_name, recipient_emailids, username_smtp_details, password_smtp_details, host_name, port_number, subject_details,  body_html_details, convert_df_to_html):
    try:
        SENDER = sender_email
        SENDERNAME = sender_name
        
        RECIPIENT = recipient_emailids
        
        USERNAME_SMTP = username_smtp_details
        PASSWORD_SMTP = password_smtp_details
        
        HOST = host_name
        PORT = port_number
        
        SUBJECT = subject_details
        
        BODY_HTML = body_html_details
        
        msg = MIMEMultipart('alternative')
        msg['Subject'] = SUBJECT
        msg['From'] = formataddr((SENDERNAME, SENDER))
        msg['To'] = ", ".join(RECIPIENT)
        
        part2 = MIMEText(BODY_HTML, 'html')
        
        msg.attach(part2)
        
        with SMTP_SSL(HOST, PORT) as server:
            server.login(USERNAME_SMTP, PASSWORD_SMTP)
            server.sendmail(SENDER, RECIPIENT, msg.as_string())
            server.close()
            print("Email sent!")        
    except Exception as e:
        raise Exception(e)
        
"""
Function Name: trigger_notification

Description: Method is used to contruct the email based on the iputs and call sent email method to send notification 

Parameters    :
common_config_s3_bucket - Bucket name where the email config resides
common_config_s3_filepath - File Path exluding the bucket name where the email config resides
subject_details - Custome subject according to notification as String
event_type - Name of the Event such as info,error as string
body_html_details - custom Body of the email to be sent as string
logger - activer logger instance
"""          
def trigger_notification(common_config_s3_bucket, common_config_s3_filepath, subject_details, event_type, body_html_details,logger):
    try:
        common_config_details = get_config_details(common_config_s3_bucket, common_config_s3_filepath)
        
        sender_email = common_config_details["email_notification"]["sender_email"]
        sender_name = common_config_details["email_notification"]["sender_name"]
        recipient_emailids = common_config_details["email_notification"]["recipient_emailids"]
        secret_name = common_config_details["email_notification"]["secret_name"]
        sectrets_data = get_secret(secret_name)
        username_smtp_details = sectrets_data["username_smtp"]
        password_smtp_details = sectrets_data["password_smtp"]
        host_name = sectrets_data["host"]
        port_number = sectrets_data["port"]
        convert_df_to_html = "Hi"
        subject_details = event_type + ": " +  subject_details
        body_html_details = body_html_details
        
        send_email(sender_email, sender_name, recipient_emailids, username_smtp_details, password_smtp_details, host_name, port_number, subject_details,  body_html_details, convert_df_to_html)
    except Exception as e:
        logger.error('Error occured in trigger_notification Method. Error description is - {}'.format(str(e)))
        raise Exception(e)

"""
Function Name : get_last_modified_date

Description   : Method for getting last modified date of bronze files for particular table.

Parameters    :
bucket_name - Source Bronze bucket name
prefix - File path where data resides for particular table.
logger - activer logger instance

returns: last_modified_date(string) if available
"""       
def get_last_modified_date(bucket_name, prefix,logger):
    try:
        logger.info("Entered into get_last_modified_date")
        logger.info("bucket_name is - {}".format(bucket_name))
        logger.info("prefix is - {}".format(prefix))
        response = s3_client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=prefix
        )
        if 'Contents' in response:
            logger.info("Contents is - {}".format(response['Contents']))
            # Extract last modified dates from response
            last_modified_dates = [obj['LastModified'] for obj in response['Contents']]
            logger.info("last_modified_dates is - {}".format(last_modified_dates))
            # Find the latest last modified date
            last_modified_date = max(last_modified_dates)
            return last_modified_date
        else:
            return None
    except Exception as e:
        logger.info("Error occured in get_last_modified_date. Error - {}".format(str(e)))
        raise Exception(e)

"""
Function Name: move_s3_folder_contents

Description: Method for getting last modified date of bronze files for particular table.

Parameters:
source_bucket - Source bucket name from where data has to be moved 
source_folder - File Path exluding the bucket name where data resides for particular table.
destination_bucket - destination bucket name
destination_folder - File Path exluding the bucket name where data has to be moved to.
logger - activer logger instance
"""           
def move_s3_folder_contents(source_bucket, source_folder, destination_bucket, destination_folder, logger):
    try:
        # List objects in the source folder
        response = s3_client.list_objects_v2(Bucket=source_bucket, Prefix=source_folder)
        
        # Move each object to the destination folder
        for obj in response.get('Contents', []):
            # Extract the object key
            object_key = obj['Key']
            
            # Extract the object key relative to the source folder
            relative_key = object_key[len(source_folder):]
            
            # Construct the destination key by appending the relative key to the destination folder
            destination_key = f"{destination_folder}{relative_key}"
            
            # Get the size of the object
            response_head = s3_client.head_object(Bucket=source_bucket, Key=object_key)
            object_size = response_head['ContentLength']
            
            if object_size > 5 * 1024 * 1024 * 1024:  # 5 GB
                # For large objects, use multipart upload
                response_upload = s3_client.create_multipart_upload(Bucket=destination_bucket, Key=destination_key)
                upload_id = response_upload['UploadId']
                
                # Calculate the number of parts to split the object into
                part_size = 1024 * 1024 * 1024  # 1 GB
                part_count = (object_size + part_size - 1) // part_size
                
                # Upload each part
                parts = []
                for i in range(part_count):
                    start_byte = i * part_size
                    end_byte = min((i + 1) * part_size - 1, object_size - 1)
                    
                    response_copy_part = s3_client.upload_part_copy(
                        Bucket=destination_bucket,
                        Key=destination_key,
                        PartNumber=i + 1,
                        UploadId=upload_id,
                        CopySource={'Bucket': source_bucket, 'Key': object_key},
                        CopySourceRange=f"bytes={start_byte}-{end_byte}"
                    )
                    
                    parts.append({'PartNumber': i + 1, 'ETag': response_copy_part['CopyPartResult']['ETag']})
                
                # Complete multipart upload
                s3_client.complete_multipart_upload(
                    Bucket=destination_bucket,
                    Key=destination_key,
                    UploadId=upload_id,
                    MultipartUpload={'Parts': parts}
                )
            else:
                # For small objects, use regular copy
                s3_client.copy_object(
                    CopySource={'Bucket': source_bucket, 'Key': object_key},
                    Bucket=destination_bucket,
                    Key=destination_key
                )
    except Exception as e:
        logger.info("Error occurred in move_s3_folder_contents. Error - {}".format(str(e)))
        raise Exception(e)

"""
Function Name: delete_old_objects

Description: Method for getting last modified date of bronze files for particular table.

Parameters:
bucket_name - bucket name from where data has to be deleted 
folder_name - File Path exluding the bucket name where data has to be deleted 
days_to_keep - No of days that archival can be kept for 
logger - activer logger instance
"""           
def delete_old_objects(bucket_name, folder_name, days_to_keep,logger):
    try:
        # Define the timezone
        tz = pytz.timezone('UTC')
        
        # Calculate cutoff date
        cutoff_date = datetime.now(tz) - timedelta(days=int(days_to_keep))
        
        # List objects in the folder
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=folder_name)
        
        # Delete objects older than cutoff date
        if 'Contents' in response:
            for obj in response['Contents']:
                last_modified = obj['LastModified'].replace(tzinfo=pytz.UTC)
                if last_modified < cutoff_date:
                    s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
                    print(f"Deleted: {obj['Key']}")
                else:
                    logger.info("No files to be deleted")
        else:
            logger.info("No files available in the archive location")
    except Exception as e:
        logger.info("Error occured in delete_old_objects. Error - {}".format(str(e)))
        raise Exception(e)

"""
Function Name : data_archival

Description   : Method for getting last modified date of bronze files for particular table.

Parameters    :
archival_s3_bucket - Bucket name where data has to be archived 
data_source - data source name of which data has to be archived
dbname - dbname name of which data has to be archived
table_details - dictionary that consists of source and target archival bucket, target location and archival duration 
logger - activer logger instance
""" 
def data_archival(archival_s3_bucket, data_source, dbname, table_details,logger):
    try:
        logger.info("Data archive process for data source - {}, Database - {}, Table - {} is started..!!".format(data_source, dbname,  table_details["source_table_name"]))
        source_archive_bucket = table_details["source_archive_bucket"]
        target_archive_bucket = table_details["target_archive_bucket"]
        source_s3_location_temp = table_details["target_location"]
        logger.info("source_s3_location_temp is - {}".format(source_s3_location_temp))
        source_s3_location = source_s3_location_temp.split("/", 3)[3]
        archive_duration = table_details["archive_duration"]
        
        logger.info("source_archive_bucket is - {}".format(source_archive_bucket))
        logger.info("target_archive_bucket is - {}".format(target_archive_bucket))
        logger.info("source_s3_location is - {}".format(source_s3_location))
        logger.info("archive_duration is - {}".format(archive_duration))
        
        resp_source = s3_client.list_objects_v2(Bucket=archival_s3_bucket, Prefix=source_s3_location)
        
        logger.info("resp_source is - {}".format(resp_source))
        
        if 'Contents' in resp_source:
            last_modified_date = get_last_modified_date(archival_s3_bucket, source_s3_location,logger)
            if last_modified_date:
                # Convert last modified date to a human-readable format
                last_modified_date_str = last_modified_date.strftime('%Y-%m-%d')
                archive_s3_location = table_details["archive_location"]
                
            # delete objects older than 'x' days
            delete_old_objects(archival_s3_bucket, archive_s3_location, archive_duration, logger)
            move_s3_folder_contents(source_archive_bucket, source_s3_location, target_archive_bucket, archive_s3_location, logger)
            logger.info("Data archive process for data source - {}, Database - {}, Table - {} is completed..!!".format(data_source, dbname,  table_details["source_table_name"]))
        else:
            logger.info("No files available for archival")
    except Exception as e:
        logger.info("Error occured in data_archival. Error - {}".format(str(e)))
        raise Exception(e)


"""
Function Name : data_archival_files

Description   : Method for getting last modified date of bronze files for particular table.

Parameters    :
archival_s3_bucket - Bucket name where data has to be archived 
data_source - data source name of which data has to be archived
dbname - dbname name of which data has to be archived
table_details - dictionary that consists of source and target archival bucket, target location and archival duration 
logger - activer logger instance
""" 
def data_archival_files(archival_s3_bucket, data_source, dbname, table_details,logger):
    try:
        logger.info("Data archive process for data source - {}, Database - {}, Table - {} is started..!!".format(data_source, dbname,  table_details["source_file_name"]))
        source_archive_bucket = table_details["source_archive_bucket"]
        target_archive_bucket = table_details["target_archive_bucket"]
        source_s3_location_temp = table_details["target_location"]
        logger.info("source_s3_location_temp is - {}".format(source_s3_location_temp))
        source_s3_location = source_s3_location_temp.split("/", 3)[3]
        archive_duration = table_details["archive_duration"]
        
        logger.info("source_archive_bucket is - {}".format(source_archive_bucket))
        logger.info("target_archive_bucket is - {}".format(target_archive_bucket))
        logger.info("source_s3_location is - {}".format(source_s3_location))
        logger.info("archive_duration is - {}".format(archive_duration))
        
        resp_source = s3_client.list_objects_v2(Bucket=archival_s3_bucket, Prefix=source_s3_location)
        
        logger.info("resp_source is - {}".format(resp_source))
        
        if 'Contents' in resp_source:
            last_modified_date = get_last_modified_date(archival_s3_bucket, source_s3_location,logger)
            if last_modified_date:
                # Convert last modified date to a human-readable format
                last_modified_date_str = last_modified_date.strftime('%Y-%m-%d')
                archive_s3_location = table_details["archive_location"]
                
            # delete objects older than 'x' days
            delete_old_objects(archival_s3_bucket, archive_s3_location, archive_duration, logger)
            move_s3_folder_contents(source_archive_bucket, source_s3_location, target_archive_bucket, archive_s3_location, logger)
            logger.info("Data archive process for data source - {}, Database - {}, Table - {} is completed..!!".format(data_source, dbname,  table_details["source_file_name"]))
        else:
            logger.info("No files available for archival")
    except Exception as e:
        logger.info("Error occured in data_archival. Error - {}".format(str(e)))
        raise Exception(e)
        
"""
Function Name : read_redshift

Description   : Method for getting last modified date of bronze files for particular table.

Parameters    :
spark - active Spark session as the parameter 
table_details - Dictionary that consists of schema, source columns, tablename, databasename
sectrets_data - Credentials for mySQL Database in json object
logger - activer logger instance

returns: df(spark dataframe)
"""        
def read_redshift(spark,table_details,sectrets_data,logger):
    try: 
        logger.info("Read redshift process for table - {} is started..!!".format(table_details["source_table_name"]))
        redshift_url = sectrets_data["redshift_url"]
        print(sectrets_data["redshift_url"])
        print(sectrets_data["user"])
        print(sectrets_data["password"])
        print(sectrets_data["driver"])
    
        redshift_properties = {
            "user": sectrets_data["user"],
            "password": sectrets_data["password"],
            "driver": sectrets_data["driver"]
        }
        db_tablename = table_details["schema"]+"."+table_details["source_table_name"]
        
        df = spark.read \
            .format("jdbc") \
            .option("url", redshift_url) \
            .option("dbtable", db_tablename) \
            .option("user", redshift_properties["user"]) \
            .option("password", redshift_properties["password"]) \
            .option("driver", redshift_properties["driver"]) \
            .load()
        logger.info("Read redshift process for table - {} is completed..!!".format(table_details["source_table_name"]))
    except Exception as e:
        logger.error("Error occured in read_redshift Method. Error description is - {}".format(str(e)))
        raise Exception(e)
    return df

def insert_into_control_table(common_config_s3_bucket,common_config_s3_filepath, job_name, data_source, source_database, source_table, target_layer, target_database, target_table, source_count, target_count, load_date, load_status, load_start_time, load_end_time, logger):
    try:
        common_config_details = get_config_details(common_config_s3_bucket, common_config_s3_filepath)
        
        secret_name = common_config_details["lm_control_table_rds"]["secret_name"]
        db_driver = common_config_details["lm_control_table_rds"]["db_driver"]
        jdbc_driver_path = common_config_details["lm_control_table_rds"]["jdbc_driver_path"]
        
        rds_secrets = get_secret(secret_name)
        db_name = rds_secrets['dbInstanceIdentifier']
        table_name = common_config_details["lm_control_table_rds"]["control_table"]
        
        # Establish the connection
        conn = pymysql.connect( host=rds_secrets["host"], user=rds_secrets['username'], password = rds_secrets['password'], db=rds_secrets['dbInstanceIdentifier'],)
        cursor = conn.cursor()
        
        #load_start_time_str = "{load_start_time}".format(**kw_control_rds_dict)
        #load_end_time_str = "{load_end_time}".format(**kw_control_rds_dict)
        job_run_time = str(datetime.strptime(load_end_time, "%Y-%m-%d %H:%M:%S") - datetime.strptime(load_start_time,"%Y-%m-%d %H:%M:%S"))
        created_on = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        # Define the insert query
        insert_query = f"INSERT INTO {db_name}.{table_name} (job_name, source_data, source_database, source_table, target_layer, target_database, target_table, source_count, target_count, load_date, load_status, load_start_time, load_end_time, job_run_time, created_on) VALUES ('{job_name}', '{data_source}', '{source_database}', '{source_table}', '{target_layer}', '{target_database}', '{target_table}', '{source_count}', '{target_count}', '{load_date}', '{load_status}', '{load_start_time}', '{load_end_time}', '{job_run_time}', '{created_on}')"

        logger.info("insert_query is - {}".format(insert_query))
        
        # Execute the insert query
        cursor.execute(insert_query)
        conn.commit()
        # Close the cursor and connection
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error("Error occured in insert_into_control_table Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def read_data_control_table(common_config_s3_bucket,common_config_s3_filepath, data_source, source_database, source_table, logger):
    try:
        common_config_details = get_config_details(common_config_s3_bucket, common_config_s3_filepath)
        
        secret_name = common_config_details["lm_control_table_rds"]["secret_name"]
        db_driver = common_config_details["lm_control_table_rds"]["db_driver"]
        jdbc_driver_path = common_config_details["lm_control_table_rds"]["jdbc_driver_path"]
        
        rds_secrets = get_secret(secret_name)

        db_name = rds_secrets['dbInstanceIdentifier']
        table_name = common_config_details["lm_control_table_rds"]["control_table"]
        
        # Establish the connection
        conn = pymysql.connect( host=rds_secrets["host"], user=rds_secrets['username'], password = rds_secrets['password'], db=rds_secrets['dbInstanceIdentifier'],)
        cursor = conn.cursor()
        
        #Define Select query
        select_query = f"SELECT max(load_date) FROM {db_name}.{table_name} where source_data = '{data_source}' and source_database = '{source_database}' and source_table = '{source_table}'"
        
        # Execute the select query
        cursor.execute(select_query)

        # Fetch all rows from the result set
        rows = cursor.fetchall()

        # Display fetched rows
        for row in rows:            
            for item in row:
                if(item is not None):
                    last_load_date = str(item) + " 00:00:00"
                else:
                    last_load_date = '1990-01-01 00:00:00'
        # conn.commit()
        # Close the cursor and connection
        cursor.close()
        conn.close()
        return last_load_date
    except Exception as e:
        logger.error("Error occured in read_data_control_table Method. Error description is - {}".format(str(e)))
        raise Exception(e)