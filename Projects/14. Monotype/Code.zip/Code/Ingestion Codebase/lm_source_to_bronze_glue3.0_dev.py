import sys, boto3, datetime, json, time
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
import datetime
import logging
from datetime import datetime  
from threading import Thread
import time
import pytz
ist = pytz.timezone('Asia/Kolkata')
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from pyspark.sql.functions import *
from pyspark.sql.functions import current_timestamp,max,lit,udf

import time

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "notification_flag", "thread_count", "multithreading_flag","ds_platform_mysql","ds_heap_redshift", "ds_mongodb", "ds_snowflake", "common_config_s3_bucket" , "common_config_s3_filepath"])                        

jobName = args['JOB_NAME']
jobRunId = args['JOB_RUN_ID']
config_s3_bucket = args['config_s3_bucket']
config_s3_filepath = args['config_s3_filepath']
utility_s3_filepath = args['utility_s3_filepath']
notification_flag = args['notification_flag']
thread_count = int(args['thread_count'])
multithreading_flag = args['multithreading_flag']
ds_platform_mysql = args['ds_platform_mysql']
ds_heap_redshift = args['ds_heap_redshift']
ds_mongodb = args['ds_mongodb']
ds_snowflake = args['ds_snowflake']
common_config_s3_bucket = args['common_config_s3_bucket']
common_config_s3_filepath = args['common_config_s3_filepath']

logger.info("Value of ds_platform_mysql is - {}".format(ds_platform_mysql))
logger.info("Value of ds_heap_redshift is - {}".format(ds_heap_redshift))
logger.info("Value of ds_mongodb is - {}".format(ds_mongodb))
logger.info("Value of ds_snowflake is - {}".format(ds_snowflake))

# Initializing the SparkContext, GlueContext and SQL Context
conf = SparkConf()
sparkContext = SparkContext(conf=conf)

glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session.builder.config('spark.jars.packages', 's3://dl-cdl-dev-bronze/code_deployment/external_jars/mongo-spark-connector_2.13-10.2.1.jar').getOrCreate()
#sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInWrite","LEGACY")

# Import custom common functions from utility
import lm_common_utility as lmcu

config_details = lmcu.get_config_details(config_s3_bucket, config_s3_filepath)
logger.info("config_details is - {}".format(config_details))

info_event_type = "INFO"
error_event_type = "ERROR"

global validation_df

def unix_timestamp_to_datetime(unix_timestamp):
    import datetime
    if isinstance(unix_timestamp, int) and unix_timestamp is not None:
        return datetime.datetime.fromtimestamp(unix_timestamp / 1000)
    else:
        return None
        
# Register the UDF
udf_unix_timestamp_to_datetime = udf(unix_timestamp_to_datetime, TimestampType())

def build_base_validation():
    try:
        schema = StructType([
                        StructField("data_source", StringType(), True),
                        StructField("source_database_name", StringType(), True),
                        StructField("source_table_name", StringType(), True),
                        StructField("source_count", IntegerType(), True),
                        StructField("data_target", StringType(), True),
                        StructField("target_database_name", StringType(), True),
                        StructField("target_table_name", StringType(), True),
                        StructField("target_count", IntegerType(), True),
                        StructField("status", StringType(), True)
                ])
        return schema        
    except Exception as e:
        logger.error("Error occured in build_base_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def data_validation(sparkSession, data_source_name, source_database_name, source_table_name, source_count, target_database_name, target_table_name, target_count):
    try:
        global validation_df
        schema = build_base_validation()

        if source_count == target_count:
            status = "Matched"
        else:
            status = "Not Matched"

        data = [(data_source_name, source_database_name, source_table_name, source_count, "Bronze Database", target_database_name, target_table_name, target_count, status)]

        validation_df = sparkSession.createDataFrame(data, schema)

        return validation_df
    except Exception as e:
        logger.error("Error occured in data_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def prepare_data_validation(sparkSession, df, data_source, database, table_details):
    try:
        global validation_df
        #Data Validation input generation
        source_count = df.count()
        logger.info("101")
        df_target = sparkSession.read.table(table_details["target_database_name"]+"."+table_details["target_table_name"])
        logger.info("102")
        target_count = df_target.count()
        logger.info("103")

        time.sleep(10)
        validation_df = validation_df.union(data_validation(sparkSession, data_source["data_source"], database["databasename"], table_details["source_table_name"], source_count, table_details["target_database_name"], table_details["target_table_name"], target_count))

        logger.info("validation_df is - {}".format(validation_df.show()))
        logger.info("count validation_df is - {}".format(validation_df.count()))
    except Exception as e:
        logger.error("Error occured in prepare_data_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)


def send_validation_results(validation_df, data_source_name):
    try:
        convert_df_to_html = validation_df.toPandas().to_html()

        logger.info("105")
        body_html_details = f"""<html>
                <head></head>
                <body>
                <p>Please find the Data Validation results for data source - {data_source_name}</p>
                {convert_df_to_html}
                </body>
                </html>"""
        lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, body_html_details, logger)
    except Exception as e:
        logger.error("Error occured in send_validation_results Method. Error description is - {}".format(str(e)))
        raise Exception(e)

"""
Method Name: write_into_raw_table

Description: Used to write dataframe data into parquet file in the given location

parameters:
sparkSession - active Spark session as the parameter 
df - data in dataframe to write
table_details - dictionary that contains target location and write mode 
"""
def write_into_raw_table(sparkSession,df,table_details):
    try:
        # target_database_name = table_details['target_database_name']
        # target_table_name = table_details['target_table_name']
        # target_raw_table_name = table_details['target_raw_table_name']
        # target_partition_col = table_details['target_partition_col']
        # target_repartition_no = table_details["target_repartition_no"]
        write_mode = table_details['target_raw_write_mode']

        df.write.mode(write_mode).parquet(table_details["target_raw_location"])
        
    except Exception as e:
        raise Exception(e)

"""
Method Name: read_json_schema

Description: Read json schema from gived location and retirn schema in json object

parameters:
bucket_name - bucket name of schema file
table_details - dictionary that contains table details like source table name
schema_path - path of schema file excluding bucket  name  

returns: configutation(json object)
"""
def read_json_schema(bucket_name, table_details, schema_path):
    # collection = table_details['source_table_name']
    s3_client = boto3.client('s3')
    response = s3_client.get_object(Bucket=bucket_name, Key=schema_path)
    config_data = response['Body'].read().decode('utf-8')
    config_data=json.dumps(config_data)
    configutation = json.loads(config_data)
    return configutation
    
"""
Method Name: read_data_from_raw_table

Description: Method is used to read data from parquet file

parameters:
sparkSession - active Spark session as the parameter 
df - data in dataframe to write
table_details - dictionary that contains table details like columns with different data types

returns: raw_df(spark dataframe)
"""
def read_data_from_raw_table(sparkSession,dbname,table_details,secrets):

    try:
        # collection = table_details['source_table_name']
        # mongodb_uri = secrets["mongodb_uri"]
        # column_list = table_details['select_column']
        # cdc_column = table_details['cdc_column']
        # target_database_name = table_details['target_database_name']
        # target_table_name = table_details['target_table_name']
        # target_raw_table_name = table_details['target_raw_table_name']
        # load_type = table_details["load_type"]
        timestamp_columns = table_details["timestamp_columns"]
        integer_columns = table_details["integer_columns"]
        boolean_columns = table_details["boolean_columns"]

        #raw_df = sparkSession.read.table(target_database_name+"."+target_raw_table_name)
        raw_df = sparkSession.read.parquet(table_details["target_raw_location"])
        
        for column in timestamp_columns:
            
            raw_df = raw_df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))

            raw_df = raw_df.withColumn(column,
                when(col(column).like("%date%"),
                    udf_unix_timestamp_to_datetime(
                        expr("cast(get_json_object(" + column + ", '$.$date') as bigint)")
                    )
                ).otherwise(
                    to_timestamp(col(column), "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
                )
            )
            
        for column in boolean_columns:
            # Replace empty strings with None
            raw_df = raw_df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
            
            raw_df = raw_df.withColumn(column, col(column).cast("boolean"))
            
        for column in integer_columns:
            # Replace empty strings with None
            raw_df = raw_df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))

            raw_df = raw_df.withColumn(column, col(column).cast("integer"))

    except Exception as e:
        raise Exception(e)
    
    else:
        return raw_df


"""
Function Name: write_into_table

Description: Method is used for writing data into s3 and create glue catalog table based on the input parameters 

Parameters:
sparkSession: active Spark session as the parameter 
raw_df - data in dataframe to write
table_details - Table Details is a dictionary that consist of target database name, table name, partition col, writemode information
""" 
def write_into_table(sparkSession,raw_df,table_details):
    try:
        target_database_name = table_details['target_database_name']
        target_table_name = table_details['target_table_name']
        target_raw_table_name = table_details['target_raw_table_name']
        target_partition_col = table_details['target_partition_col']
        target_repartition_no = table_details["target_repartition_no"]
        write_mode = table_details['target_write_mode']

        # df = df.withColumn("inserted_timestamp", current_timestamp())

        if(sparkSession.catalog._jcatalog.tableExists(target_database_name+"."+target_table_name)):
            raw_df.write.mode(write_mode).insertInto(target_database_name+"."+target_table_name)
        else:
            if(target_partition_col == ""):
                raw_df.write.mode(write_mode).saveAsTable(target_database_name+"."+target_table_name, path=table_details["target_location"])
            else:
                raw_df.write.mode(write_mode).partitionBy(target_partition_col).saveAsTable(target_database_name+"."+target_table_name, path=table_details["target_location"])
        
    except Exception as e:
        raise Exception(e)
    
"""
Function Name: read_data

Description: Read data from Mongo db based on the input parameters 

Parameters:
sparkSession: active Spark session as the parameter 
dbname - name of the data base
table_details - Table Details is a dictionary that consist of source table name, column name, target table name, database name...
secrets -  json Object that consist of Mongo db URI 

returns: df(spark dataframe)
"""
def read_data(sparkSession,dbname,table_details,secrets):
    try:
        collection = table_details['source_table_name']
        mongodb_uri = secrets["mongodb_uri"]
        column_list = table_details['select_column']
        cdc_column = table_details['cdc_column']
        target_database_name = table_details['target_database_name']
        target_table_name = table_details['target_table_name']
        load_type = table_details["load_type"]
        
        logger.info(f"mongodb_uri: {mongodb_uri}")
        
        source_schema_enforce_location = table_details["source_schema_enforce_location"]
        source_schema_bucket = source_schema_enforce_location.split("/", 3)[2]
        source_schema_path = source_schema_enforce_location.split("/", 3)[3]
        
        configutation = read_json_schema(source_schema_bucket, table_details, source_schema_path)
        parsed_schema = StructType.fromJson(json.loads(configutation))

        start_timestamp = datetime.now()

        if load_type == "I":
            if(sparkSession.catalog._jcatalog.tableExists(target_database_name+"."+target_table_name)):
                target_df = sparkSession.read.table(f"{target_database_name}.{target_table_name}")

                if 'end_timestamp' in target_df.columns:
                    max_end_timestamp = target_df.select(max("end_timestamp")).collect()[0][0]
                    end_timestamp = max_end_timestamp.isoformat() + 'Z'
                    logger.info(f"end_timestamp1: {end_timestamp}")
                else:
                    date_time = datetime.strptime("1950-12-10", '%Y-%m-%d')
                    end_timestamp = date_time.isoformat() + 'Z'
                    logger.info(f"end_timestamp2: {end_timestamp}")
            else:
                    date_str = "1950-12-10"
                    date_time = datetime.strptime("1950-12-10", '%Y-%m-%d')
                    end_timestamp = date_time.isoformat() + 'Z'
                    logger.info(f"end_timestamp3: {end_timestamp}")

            logger.info(f"final_end_timestamp: {end_timestamp}")
            
            incremental_filter = {"$or": []}
            if cdc_column is not None and cdc_column != "":
                cnt = 1
                for col_name in cdc_column.split(","):
                    if cnt > 1:
                        conditions = {col_name: {"$gt": {'$date': end_timestamp}}}
                        incremental_filter["$or"].append(conditions)
                    else:
                        conditions = {col_name: {"$gt": {'$date': end_timestamp}}}
                        incremental_filter["$or"].append(conditions)
                        cnt+=1
                                    
            logger.info(f"mongo_filters: {incremental_filter}")
                        
            pipeline = [{'$match': incremental_filter}]

            logger.info(f"pipeline: {pipeline}")

            # df = sparkSession.read.table(f"{target_database_name}.{target_table_name}")

            df = sparkSession.read.format("com.mongodb.spark.sql.DefaultSource") \
                .option("uri", mongodb_uri) \
                .option("database", dbname) \
                .option("collection", collection) \
                .option("pipeline", pipeline) \
                .schema(parsed_schema) \
                .load() \
                .withColumn("start_timestamp", lit(start_timestamp)) \
                .withColumn("end_timestamp", current_timestamp())
            
        else:
            df = sparkSession.read.format("com.mongodb.spark.sql.DefaultSource") \
                .option("uri", mongodb_uri) \
                .option("database", dbname) \
                .option("collection", collection) \
                .schema(parsed_schema) \
                .load() \
                .withColumn("start_timestamp", lit(start_timestamp)) \
                .withColumn("end_timestamp", current_timestamp())
        
    except Exception as e:
        raise Exception(e)
    
    return df

"""
Function Name: process_mongodb_data

Description: Process Mongo db data based on given input parameter

Parameters:
sparkSession - active Spark session as the parameter 
database - name of the data base
table_details - Table Details is a dictionary that consist of source table name, column name, target table name, database name...
sectrets_data -  json Object that consist of Mongo db URI 

returns: df(spark dataframe)
"""
def process_mongodb_data(sparkSession, data_source, database, table_details,sectrets_data):
    try:
        global validation_df
        logger.info("Process started for MongoDB, database - {}, Table - {}".format(database["databasename"], table_details["source_table_name"])) 
        
        # Reading data from MongoDB data source
        df = read_data(sparkSession,database["databasename"],table_details,sectrets_data)
        logger.info("Schema of df is - {}".format(df.printSchema()))
        logger.info("Count of df is - {}".format(df.count()))
        
        # Writing df data into raw location
        write_into_raw_table(sparkSession,df,table_details)
        
        # Reading data from raw location and do type cast
        raw_df = read_data_from_raw_table(sparkSession,database["databasename"],table_details,sectrets_data)
        logger.info("Schema of raw_df after type cast is - {}".format(raw_df.printSchema()))
        logger.info("Count of raw_df after type cast is - {}".format(raw_df.count()))
        
        # Write data into Target location after Type casting
        write_into_table(sparkSession,raw_df,table_details)
        
        logger.info("Process completed for MongoDB, database - {}, Table - {}".format(database["databasename"], table_details["source_table_name"]))
        
        #Data validation
        prepare_data_validation(sparkSession, raw_df, data_source, database, table_details)
    except Exception as e:
        logger.info("Error occured in main method. Error - {}".format(str(e)))
        raise Exception(e)
    
try:
    schema = build_base_validation()
    data = []
    validation_df = sparkSession.createDataFrame(data, schema)
    for data_source in config_details["data_sources"]:
        if(ds_mongodb == "mtf_mongodb" and data_source["data_source"]== "mtf_mongodb"):
            for database in data_source["databases"]:
                secret_name = database["secret_name"]
                sectrets_data = lmcu.get_secret(secret_name)
                mongodb_uri = sectrets_data["mongodb_uri"]
                for table_details in database["table_details"]:
                    process_mongodb_data(sparkSession, data_source, database, table_details,sectrets_data)
            send_validation_results(validation_df, data_source["data_source"])
        else:
            logger.info("data_source is not properly defined")
            
    lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_glue3.0_dev", info_event_type, "The Ingestion Glue job for MongoDB data source has been completed Successfully..!!", logger)                    
except Exception as e:
    lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_glue3.0_dev", error_event_type, "The Ingestion Glue job for MongoDB data source has been failed. Error Description is - {}".format(str(e)), logger)
    logger.info("Error occured in main method. Error - {}".format(str(e)))
    raise Exception(e)

logger.info("Job completed for MongoDB data source..!!")

## Job Execution Ended..!!
glueJob.commit()