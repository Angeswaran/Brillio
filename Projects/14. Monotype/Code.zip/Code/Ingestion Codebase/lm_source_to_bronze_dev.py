import sys, boto3, datetime, json, time
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
import datetime
import logging
from datetime import datetime, timedelta, date 
from threading import Thread
import time
import pytz
#ist = pytz.timezone('Asia/Kolkata')
#from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format, lit, current_timestamp, current_date, date_sub
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType
from email.utils import formataddr
from smtplib import SMTP_SSL, SMTPException
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import time
import requests
from pyspark.sql import functions as F

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "notification_flag", "thread_count", "multithreading_flag","ds_platform_mysql","ds_heap_redshift", "ds_mongodb", "ds_snowflake", "ds_usage_s3", "ds_pageview_daily_api", "common_config_s3_bucket", "common_config_s3_filepath", "archival_s3_bucket"])                        

jobName = args['JOB_NAME']
jobRunId = args['JOB_RUN_ID']
config_s3_bucket = args['config_s3_bucket']
config_s3_filepath = args['config_s3_filepath']
utility_s3_filepath = args['utility_s3_filepath']
notification_flag = args['notification_flag']
thread_count = int(args['thread_count'])
multithreading_flag = args['multithreading_flag']
ds_platform_mysql = args['ds_platform_mysql']
ds_heap_redshift = args['ds_heap_redshift']
ds_mongodb = args['ds_mongodb']
ds_snowflake = args['ds_snowflake']
#last_load_date = args['last_load_date']
ds_usage_s3 = args['ds_usage_s3']
ds_pageview_daily_api = args['ds_pageview_daily_api']

common_config_s3_bucket = args['common_config_s3_bucket']
common_config_s3_filepath = args['common_config_s3_filepath']
archival_s3_bucket = args['archival_s3_bucket']

logger.info("Value of ds_platform_mysql is - {}".format(ds_platform_mysql))
logger.info("Value of ds_heap_redshift is - {}".format(ds_heap_redshift))
logger.info("Value of ds_mongodb is - {}".format(ds_mongodb))
logger.info("Value of ds_snowflake is - {}".format(ds_snowflake))
logger.info("Value of ds_usage_s3 is - {}".format(ds_usage_s3))

# Initializing the SparkContext, GlueContext and SQL Context
conf = SparkConf()
sparkContext = SparkContext(conf=conf)
glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInWrite","LEGACY")
sparkSession.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")

# Import custom common functions from utility
import lm_common_utility as lmcu

config_details = lmcu.get_config_details(config_s3_bucket, config_s3_filepath)

sparkSession.conf.set("spark.sql.adaptive.enabled", "true")

s3_client = boto3.client('s3')

info_event_type = "INFO"
error_event_type = "ERROR"

#global validation_df

def build_base_validation():
    try:
        schema = StructType([
                        StructField("data_source", StringType(), True),
                        StructField("source_database_name", StringType(), True),
                        StructField("source_table_name", StringType(), True),
                        StructField("source_count", IntegerType(), True),
                        StructField("data_target", StringType(), True),
                        StructField("target_database_name", StringType(), True),
                        StructField("target_table_name", StringType(), True),
                        StructField("target_count", IntegerType(), True),
                        StructField("status", StringType(), True),
                        StructField("load_date", StringType(), True)
                ])
        return schema        
    except Exception as e:
        logger.error("Error occured in build_base_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def data_validation(sparkSession, data_source_name, source_database_name, source_table_name, source_count, target_database_name, target_table_name, target_count, load_date):
    try:
        #global validation_df
        schema = build_base_validation()

        if source_count == target_count:
            status = "Matched"
        else:
            status = "Not Matched"

        data = [(data_source_name, source_database_name, source_table_name, source_count, "Bronze Database", target_database_name, target_table_name, target_count, status, str(load_date))]

        validation_df = sparkSession.createDataFrame(data, schema)

        return validation_df
    except Exception as e:
        logger.error("Error occured in data_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def prepare_data_validation(sparkSession, df, job_name, data_source, database_name, source_table_name, target_database_name, target_table_name,  load_date, load_start_time, load_end_time):
    try:
        #Data Validation input generation
        source_count = df.count()

        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')


        target_count_df = sparkSession.sql(f"select count(*) as count from {target_database_name}.{target_table_name} where load_date = \'{load_date}\'")
        target_count = target_count_df.first()['count']

        lmcu.insert_into_control_table(common_config_s3_bucket,common_config_s3_filepath, job_name, data_source, database_name, source_table_name, "Bronze", target_database_name, target_table_name, source_count, target_count, load_date, "Success", load_start_time, load_end_time, logger)

        logger.info("Record inserted into Control table successfully..!!")

        validation_df = data_validation(sparkSession, data_source, database_name, source_table_name, source_count, target_database_name, target_table_name, target_count, load_date)

        logger.info("validation_df is - {}".format(validation_df.show()))
        logger.info("count validation_df is - {}".format(validation_df.count()))

        return validation_df
    except Exception as e:
        logger.error("Error occured in prepare_data_validation Method. Error description is - {}".format(str(e)))
        raise Exception(e)


def send_validation_results(validation_df, data_source_name):
    try:
        convert_df_to_html = validation_df.toPandas().to_html()
        body_html_details = f"""<html>
                <head></head>
                <body>
                <p>Please find the Data Validation results for data source - {data_source_name}</p>
                {convert_df_to_html}
                </body>
                </html>"""
        #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, body_html_details, logger)
    except Exception as e:
        logger.error("Error occured in send_validation_results Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def build_control_rds_dict(data_source, databasename, source_table_name, target_database_name, target_table_name, load_date, load_start_time, load_end_time):
    try:
        kw_control_rds_dict = {}
        kw_control_rds_dict["job_name"] = jobName
        kw_control_rds_dict["data_source"] = data_source
        kw_control_rds_dict["source_database"] = databasename
        kw_control_rds_dict["source_table"] = source_table_name
        kw_control_rds_dict["target_layer"] = "Bronze"
        kw_control_rds_dict["target_database"] = target_database_name
        kw_control_rds_dict["target_table"] = target_table_name        
        kw_control_rds_dict["load_date"] = load_date
        kw_control_rds_dict["load_status"] = "Success"
        kw_control_rds_dict["load_start_time"] = load_start_time 
        kw_control_rds_dict["load_end_time"] = load_end_time

        return kw_control_rds_dict
    except Exception as e:
        logger.error("Error occured in build_control_rds_dict Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def write_into_table(spark, df, table_details,logger):
    try: 
        dbname = table_details["target_database_name"]
        table_name = table_details["target_table_name"]
        partitions = None if table_details["target_partition_col"] == "" else table_details["target_partition_col"]
        write_mode = "overwrite" if table_details["target_write_mode"]  == "" else table_details["target_write_mode"]
        
        logger.info("dbname is - {}".format(dbname))
        logger.info("table_name is - {}".format(table_name))
        logger.info("partitions is - {}".format(partitions))
        logger.info("write_mode is - {}".format(write_mode))
        
        if(spark.catalog.tableExists(dbname+"."+table_name)):
            df.write.mode(write_mode).insertInto(dbname+"."+table_name, path=table_details["target_location"])            
        else:
            if(partitions == None):
                df.write.mode(write_mode).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])                
            else:
                df.write.mode(write_mode).partitionBy(partitions).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])                
    except Exception as e:
        logger.info("Failed in write_into_table method. Error is - {}".format(str(e)))
        raise Exception(e)

"""
Function Name: process_pf_mysql_data

Description: Method is used to process mysql data based on the input parameter

Parameters:
sparksession - active Spark session as the parameter 
table_details - Dictionary that contains table details like source tablename, columns, cdc
database - Source database name
sectrets_data - Credentials for mySQL Database in json object
data_source - Dictionary that consists of souce name
archival_s3_bucket - name of the archival bucket for archival
"""  
def process_pf_mysql_data(sparkSession,table_details,database,sectrets_data,data_source,archival_s3_bucket, last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, job_name):
    try:
        #global validation_df
        logger.info("Ingestion process for the Table - {} of Database - {} is started..!!".format(table_details["source_table_name"], database["databasename"]))
        load_start_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        logger.info("current_load_date is - {}".format(current_load_date))
        last_load_date = lmcu.read_data_control_table(common_config_s3_bucket,common_config_s3_filepath, data_source["data_source"], database["databasename"], table_details["source_table_name"], logger)
        logger.info("last_load_date is - {}".format(last_load_date))
        
        #last_load_date = "2024-01-01 00:00:00"
        #current_load_date = "2024-05-24 00:00:00"
        # Building Query to be executed 
        if(table_details["load_type"] == "F"):
            query = lmcu.build_full_load_query(database["databasename"],table_details["source_table_name"],table_details["select_column"])
            logger.info("Full Load query is - {}".format(query))
        elif(table_details["load_type"] == "I"):
            query = lmcu.build_delta_query(database["databasename"],table_details["source_table_name"],table_details["select_column"], table_details["cdc_column"],last_load_date,current_load_date)
            logger.info("Delta Load query is - {}".format(query))
        else:
            logger.info("load_type is not properly defined")
        
        #Reading process from data source
        df = lmcu.read_mysql(sparkSession,table_details,sectrets_data,database["databasename"],query,logger)        
        #logger.info("df count is - {}".format(df.count()))
        
        # Adding Load date column to table for identifying the load date
        df = df.withColumn("load_date", date_format(date_sub(current_date(), 1), 'yyyy-MM-dd'))
        df = df.withColumn("data_source", lit(data_source["data_source"]))
        logger.info("df Schema is - {}".format(df.printSchema()))
        
        # Writing process to Bronze Layer
        if(table_details["load_type"] == "F"):
            #Data archival process
            if(table_details["is_archive"] == "Y"):
                lmcu.data_archival(archival_s3_bucket, data_source["data_source"], database["databasename"], table_details,logger)
                logger.info("Data archival completed for Data source - {}, Data base - {}, table name - {}".format(data_source["data_source"], database["databasename"], table_details["source_table_name"]))
            else:
                logger.info("Data Archival is not required for table - {}".format(table_details["source_table_name"]))
            write_mode = "overwrite" if table_details["target_write_mode"]  == "" else table_details["target_write_mode"]
            dbname = table_details["target_database_name"]
            table_name = table_details["target_table_name"]
            df.write.mode(write_mode).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])
        elif(table_details["load_type"] == "I"):
            write_into_table(sparkSession, df, table_details,logger)
        else:
            logger.info("load_type is not properly defined")

        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')        
        load_end_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        #kw_control_rds_dict = build_control_rds_dict(data_source["data_source"], database["databasename"], table_details["source_table_name"], table_details["target_database_name"], table_details["target_table_name"], load_date, load_start_time, load_end_time)
        
        logger.info("Ingestion process for the Table - {} of Database - {} is completed..!!".format(table_details["source_table_name"], database["databasename"]))

        target_database_name = table_details["target_database_name"]
        target_table_name = table_details["target_table_name"]

        #Data validation
        output_df_list.append(prepare_data_validation(sparkSession, df, job_name, data_source["data_source"], database["databasename"], table_details["source_table_name"], target_database_name, target_table_name,load_date, load_start_time, load_end_time))
        success_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
    except Exception as e:
        failed_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
        logger.error("Error occured in process_pf_mysql_data Method. Error description is - {}".format(str(e)))
        raise Exception(e)

"""
Function Name: process_heap_redshift_data

Description: Method is used to process redshift data based on the input parameter

Parameters:
sparksession - active Spark session as the parameter 
table_details - Dictionary that contains table details like source tablename, columns, cdc
database - Source database name
sectrets_data - Credentials for mySQL Database in json object
data_source - Dictionary that consists of souce name
""" 
def process_heap_redshift_data(sparkSession,table_details,database,sectrets_data,data_source,archival_s3_bucket, output_df_list, success_tables_list, failed_tables_list, job_name):
    try:
        logger.info("Ingestion process for the Table - {} of Database - {} is started..!!".format(table_details["source_table_name"], database["databasename"]))
        load_start_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        df = lmcu.read_redshift(sparkSession,table_details,sectrets_data,logger)
        
        # Adding Load date column to table for identifying the load date
        df = df.withColumn("load_date", date_format(date_sub(current_date(), 1), 'yyyy-MM-dd'))
        df = df.withColumn("data_source", lit(data_source["data_source"]))
        logger.info("df Schema is - {}".format(df.printSchema()))
        
        # Writing process to Bronze Layer
        if(table_details["load_type"] == "F"):
            #Data archival process
            if(table_details["is_archive"] == "Y"):            
                lmcu.data_archival(archival_s3_bucket, data_source["data_source"], database["databasename"], table_details,logger)
                logger.info("Data archival completed for Data source - {}, Data base - {}, table name - {}".format(data_source["data_source"], database["databasename"], table_details["source_table_name"]))
            else:
                logger.info("Data Archival is not required for the table - {}".format(table_details["source_table_name"]))
            write_mode = "overwrite" if table_details["target_write_mode"]  == "" else table_details["target_write_mode"]
            dbname = table_details["target_database_name"]
            table_name = table_details["target_table_name"]
            df.write.mode(write_mode).saveAsTable(dbname+"."+table_name, path=table_details["target_location"])
        elif(table_details["load_type"] == "I"):
            logger.info("Incremental is not in scope for this MVP..!!")
        else:
            logger.info("load_type is not properly defined")
        
        target_database_name = table_details["target_database_name"]
        target_table_name = table_details["target_table_name"]

        #Data validation
        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        load_end_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        #kw_control_rds_dict = build_control_rds_dict(data_source["data_source"], database["databasename"], table_details["source_table_name"], table_details["target_database_name"], table_details["target_table_name"], load_date, load_start_time, load_end_time)

        output_df_list.append(prepare_data_validation(sparkSession, df, job_name, data_source["data_source"], database["databasename"], table_details["source_table_name"], target_database_name, target_table_name,load_date, load_start_time, load_end_time))

        success_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
        logger.info("Ingestion process for the Table - {} of Database - {} is completed..!!".format(table_details["source_table_name"], database["databasename"]))
    except Exception as e:
        failed_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
        logger.error("Error occured in process_heap_redshift_data Method. Error description is - {}".format(str(e)))
        raise Exception(e)
        

"""
Function Name: process_snowflake_data

Description: Method is used to process snowflake data based on the input parameter

Parameters:
sparksession - active Spark session as the parameter 
table_details - Dictionary that contains table details like source tablename, columns, cdc
database - Source database name
"""        
def process_snowflake_data(sparkSession,table_details,database, data_source,last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, job_name):
    try:
        logger.info("Ingestion process for the Table - {} of Database - {} is started..!!".format(table_details["source_table_name"], database["databasename"]))
        
        load_start_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        source_table_name = table_details['source_table_name']
        source_table_schema = table_details['source_table_schema']
        columns_list = table_details['select_column']
        write_mode = table_details['target_write_mode']
        target_database_name = table_details['target_database_name']
        target_location = table_details['target_location']
        target_table_name = table_details['target_table_name']        
        dbname = database["databasename"]

        logger.info("current_load_date is - {}".format(current_load_date))
        last_load_date = lmcu.read_data_control_table(common_config_s3_bucket,common_config_s3_filepath, data_source["data_source"], database["databasename"], table_details["source_table_name"], logger)
        logger.info("last_load_date is - {}".format(last_load_date))

        # Building Query to be executed 
        if(table_details["load_type"] == "F"):
            snowflake_query = lmcu.build_full_load_query(database["databasename"] + "." + table_details["source_table_schema"],table_details["source_table_name"],table_details["select_column"])
            logger.info("Full Load snowflake_query is - {}".format(snowflake_query))
        elif(table_details["load_type"] == "I"):
            snowflake_query = lmcu.build_delta_query(database["databasename"] + ".SALESFORCE",table_details["source_table_name"],table_details["select_column"], table_details["cdc_column"],last_load_date,current_load_date)
            logger.info("Delta Load snowflake_query is - {}".format(snowflake_query))
        else:
            logger.info("load_type is not properly defined")

        # Reading data from Snowflake as data source
        if(table_details["load_type"] == "F"):
            snowflake_dynamic_frame = glueContext.create_dynamic_frame.from_options(connection_type="snowflake",connection_options={'autopushdown': 'on','connectionName': 'Snowflake connection','query': snowflake_query,'sfdatabase':dbname})
            dataframe = snowflake_dynamic_frame.toDF()
        elif(table_details["load_type"] == "I"):
            logger.info("snowflake_query is - {}".format(snowflake_query))
            logger.info("dbname is - {}".format(dbname))
            snowflake_dynamic_frame = glueContext.create_dynamic_frame.from_options(connection_type="snowflake",connection_options={'autopushdown': 'on','connectionName': 'Snowflake connection','query': snowflake_query,'sfdatabase':dbname})
            dataframe = snowflake_dynamic_frame.toDF()
        else:
            logger.info("load_type is not properly defined")

        # Adding Load date column to table for identifying the load date
        dataframe = dataframe.withColumn("load_date", date_format(date_sub(current_date(), 1), 'yyyy-MM-dd'))
        dataframe = dataframe.withColumn("data_source", lit(data_source["data_source"]))
        logger.info("dataframe Schema is - {}".format(dataframe.printSchema()))

        # Writing process to Bronze Layer
        if(table_details["load_type"] == "F"):
            dataframe.coalesce(1).write.format("parquet").mode(write_mode).option("path", target_location).saveAsTable(f"{target_database_name}.{target_table_name}", path=table_details["target_location"])
        elif(table_details["load_type"] == "I"):
            lmcu.write_into_table(sparkSession, dataframe, table_details,logger)
        else:
            logger.info("load_type is not properly defined")
        logger.info("Ingestion process for the Table - {} of Database - {} is completed..!!".format(table_details["source_table_name"], database["databasename"]))

        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        load_end_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        #kw_control_rds_dict = build_control_rds_dict(data_source["data_source"], database["databasename"], table_details["source_table_name"], table_details["target_database_name"], table_details["target_table_name"], load_date, load_start_time, load_end_time)

        target_database_name = table_details["target_database_name"]
        target_table_name = table_details["target_table_name"]
        
        #Data validation
        output_df_list.append(prepare_data_validation(sparkSession, dataframe, job_name, data_source["data_source"], dbname, source_table_name, target_database_name, target_table_name,load_date, load_start_time, load_end_time))        

        success_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
    except Exception as e:
        failed_tables_list.append(data_source["data_source"] + "-" + database["databasename"] + "-" + table_details["source_table_name"])
        logger.error("Error occured in process_snowflake_data Method. Error description is - {}".format(str(e)))
        raise Exception(e)

def process_usage_db(sparkSession, table_details,output_df_list, success_tables_list, failed_tables_list, job_name):
    try:
        data_source = "usagedb_s3"
        database_name = "usagedb"
        logger.info("Ingestion process for the Table - {} of Database - {} is started..!!".format(table_details["source_file_name"], database_name))
        load_start_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        df = sparkSession.read.option("header", "true").csv("s3://" + table_details["source_s3_bucket"] + "/" + table_details["source_file_location"])
        
        source_file_name = table_details["source_file_name"]
        target_database_name = table_details["target_database_name"]
        target_table_name = table_details["target_table_name"]
        archival_s3_bucket = table_details["target_archive_bucket"]
        
        # Adding Load date column to table for identifying the load date
        df = df.withColumn("load_date", date_format(date_sub(current_date(), 1), 'yyyy-MM-dd'))
        df = df.withColumn("data_source", lit(data_source))
        logger.info("dataframe Schema is - {}".format(df.printSchema()))
        
        if(table_details["load_type"] == "F"):
            if(table_details["is_archive"] == "Y"):            
                lmcu.data_archival_files(archival_s3_bucket, data_source, database_name, table_details,logger)
                logger.info("Data archival completed for Data source - {}, Data base - {}, table name - {}".format(data_source, database_name, table_details["source_file_name"]))
            else:
                logger.info("Data Archival is not required for the table - {}".format(table_details["source_file_name"]))
            df.coalesce(1).write.format("parquet").mode(table_details["target_write_mode"]).option("path", table_details["target_location"]).saveAsTable(f"{target_database_name}.{target_table_name}", path=table_details["target_location"])
        elif(table_details["load_type"] == "I"):
            logger.info("Incremental is not in scope")
        else:
            logger.info("load_type is not properly defined")

        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        load_end_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        #Data validation
        output_df_list.append(prepare_data_validation(sparkSession, df, job_name, data_source, database_name, source_file_name, target_database_name, target_table_name, load_date, load_start_time, load_end_time))

        success_tables_list.append(data_source + "-" + database_name + "-" + table_details["source_file_name"])

        logger.info("Ingestion process for the Table - {} of Database - {} is completed..!!".format(table_details["source_file_name"], database_name))
    except Exception as e:
        failed_tables_list.append(data_source + "-" + database_name + "-" + table_details["source_table_name"])
        logger.error("Error occured in process_usage_db Method. Error description is - {}".format(str(e)))
        raise Exception(e)


def process_pageview_api_data(sparkSession, load_start_date, load_end_date, api_details, sectrets_data, logger, output_df_list, success_tables_list, failed_tables_list, jobName):
    try:
        logger.info("Ingestion process for the Table - {} of Database - {} is started..!!".format(api_details["source_api_name"], "pageview_daily_api"))
        load_start_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')
        
        source_columns = api_details["source_columns"]
        #source_columns = ["projectid", "apitype", "refdomain", "pvtprocesseddocument", "pageviewcount","reportingdate"]
        target_columns = api_details["target_columns"]
        #target_columns = ', '.join(f'"{str(item)}"' for item in target_columns_list)
        target_location = api_details["target_location"]
        target_database_name = api_details["target_database_name"]
        target_table_name = api_details["target_table_name"]
        pageview_api_domain = sectrets_data["pageview_api_domain"]

        logger.info("source_columns are - {}".format(source_columns))
        logger.info("type source_columns are - {}".format(type(source_columns)))        
        logger.info("target_columns are - {}".format(target_columns))
        logger.info("target_location are - {}".format(target_location))
        logger.info("target_database_name are - {}".format(target_database_name))
        logger.info("target_table_name are - {}".format(target_table_name))
        logger.info("pageview_api_domain are - {}".format(pageview_api_domain))

        df = spark.read.table("dl_bronze_dev.daily_api_pageview_data")
 
        load_start_date = df.agg(F.max('reportingdate')).collect()[0][0]
        logger.info("load_start_date - {}".format(load_start_date))
        logger.info("load_end_date - {}".format(load_end_date))

        while load_start_date < load_end_date:
            logger.info("load_start_date is - {}".format(load_start_date))
            
            es_url = "https://{}/projectid-{}-{}/_search?q=reportingDate:{}".format(str(pageview_api_domain), str(load_start_date.strftime("%Y")),str(load_start_date.    strftime("%m")),str(load_start_date.strftime("%Y-%m-%d")))        
            params = {
                "size": 10000,  # Number of documents to retrieve per scroll request
                "scroll": "1m"  # Scroll window timeout
            }
            response = requests.get(es_url, params=params)
            rows = []
            
            # # Process the initial response
            if response.status_code == 200:
                data = response.json()
                for hit in data['hits']['hits']:
                    dict = hit['_source']
                    row = str(dict['projectId']),str(dict['apiType']),str(dict['refdomain']),str(dict['pvtProcessedDocCount']),str(dict['pageViewCount']), \
                    str(dict['reportingDate'])
                    rows.append(row)
            
                a = 1
                # Continue scrolling through the results
                while len(data['hits']['hits']) > 0:
                    logger.info("a is - {}".format(a))
                    a+=1
                    scroll_id = data['_scroll_id']
                    scroll_params = {
                        "scroll": "1m"
                    }
                    scroll_data = {
                        "scroll_id": scroll_id
                    }
                    es_url_search = "https://{}/_search/scroll".format(str(str(pageview_api_domain)))
                    response = requests.post(
                        es_url_search,
                        params=scroll_params,
                        json=scroll_data
                    )
                    data = response.json()
            
                    # Process next batch of results
                    for hit in data['hits']['hits']:
                        dict = hit['_source']
                        row = str(dict['projectId']),str(dict['apiType']),str(dict['refdomain']),str(dict['pvtProcessedDocCount']),str(dict['pageViewCount']), \
                        str(dict['reportingDate'])
                        rows.append(row)
            else:
                logger.info("Error:", response.status_code)
        
            # Create spark DataFrame
            df1 = sparkSession.createDataFrame(rows,source_columns)
            df1 = df1.withColumn('reportingdate', df1['reportingdate'].cast('timestamp'))
            
            # Extract day, month, and year from reportingDate
            df1 = df1.withColumn('day', F.dayofmonth('reportingdate'))
            df1 = df1.withColumn('month', F.month('reportingdate'))
            df1 = df1.withColumn('year', F.year('reportingdate'))
            df1 = df1.withColumn('reportingdate', F.to_date(F.col('reportingdate')))
            df1 = df1.withColumn('pvtprocesseddocument', F.col('pvtprocesseddocument').cast(IntegerType()))
            df1 = df1.withColumn('pageviewcount', df1['pageviewcount'].cast('float'))
            
            #df1 = df1.select("projectid","apitype","refdomain","pvtprocesseddocument","pageviewcount","reportingdate","year","month","day")
            df1 = df1.select(target_columns)
            
            lmcu.write_into_table(sparkSession, df1, api_details,logger)
    
            load_start_date += timedelta(days=1)

        load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        
        load_end_time = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

        #kw_control_rds_dict = build_control_rds_dict("pageview_daily_api", "pageview_daily_api", api_details["source_api_name"], api_details["target_database_name"], api_details["target_table_name"], load_date, load_start_time, load_end_time)

        #Data validation
        output_df_list.append(prepare_data_validation(sparkSession, df1, "pageview_daily_api", "pageview_daily_api", api_details["source_api_name"], api_details["target_database_name"], api_details["target_table_name"], load_date, load_start_time, load_end_time))

        success_tables_list.append("pageview_daily_api" "-" + api_details["source_api_name"])

        logger.info("Ingestion process for the Table - {} of Database - {} is completed..!!".format(api_details["source_api_name"], "pageview_daily_api"))    
    except Exception as e:
        failed_tables_list.append("pageview_daily_api" "-" + api_details["source_api_name"])
        logger.error("Error occured in process_pageview_api_data Method. Error description is - {}".format(str(e)))
        raise Exception(e)

try:
    schema = build_base_validation()
    data = []
    validation_df = sparkSession.createDataFrame(data, schema)

    current_load_date = (datetime.now()).strftime('%Y-%m-%d 00:00:00')
    #current_load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    last_load_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')

    # Control table RDS credentials    
    for data_source in config_details["data_sources"]:
        if(ds_platform_mysql == "platform_mysql" and data_source["data_source"]=="platform_mysql"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                secret_name = database["secret_name"]
                sectrets_data = lmcu.get_secret(secret_name)
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    logger.info("sectrets_data is - {}".format(sectrets_data))
                    logger.info("secret_name is - {}".format(secret_name))
                    logger.info("table_details is - {}".format(table_details))
                    #process_pf_mysql_data(sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, last_load_date, current_load_date)
                    process=Thread(target=process_pf_mysql_data,args=[sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()                    
                    threads.append(process)
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for My SQL data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for My SQL data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_snowflake == "sf_snowflake" and data_source["data_source"]== "sf_snowflake"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    process=Thread(target=process_snowflake_data,args=[sparkSession,table_details,database,data_source,last_load_date, current_load_date, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()
                    threads.append(process)                    
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"])) 
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Snowflake data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Snowflake data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_heap_redshift == "heap_redshift" and data_source["data_source"]== "heap_redshift"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            for database in data_source["databases"]:
                secret_name = database["secret_name"]
                sectrets_data = lmcu.get_secret(secret_name)
                threads=[]
                output_df_list = []
                logger.info("Ingestion process for the database - {} is started..!!".format(database["databasename"]))
                for table_details in database["table_details"]:
                    if(table_details["is_hold"] == "Y"):
                        continue
                    process=Thread(target=process_heap_redshift_data,args=[sparkSession,table_details,database,sectrets_data,data_source, archival_s3_bucket, output_df_list, success_tables_list, failed_tables_list, jobName])
                    process.start()
                    threads.append(process)                    
                for process in threads:
                    process.join()
                data_validation_df = data_validation_df + output_df_list
                logger.info("Ingestion process for the database - {} is completed..!!".format(database["databasename"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)        
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_usage_s3 == "usagedb_s3" and data_source["data_source"]== "usagedb_s3"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []
            threads=[]
            output_df_list = []
            for table_details in data_source["table_details"]:
                logger.info("table_details is -{}".format(table_details))
                logger.info("Type table_details is -{}".format(type(table_details)))
                if(table_details["is_hold"] == "Y"):
                    continue
                process=Thread(target=process_usage_db,args=[sparkSession, table_details, output_df_list, success_tables_list, failed_tables_list, jobName])
                process.start()
                threads.append(process)                    
            for process in threads:
                process.join()
            data_validation_df = data_validation_df + output_df_list
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"            
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        elif(ds_pageview_daily_api == "pageview_daily_api" and data_source["data_source"]== "pageview_daily_api"):
            logger.info("Ingestion process for the data source - {} is started..!!".format(data_source["data_source"]))
            data_validation_df = []
            success_tables_list = []
            failed_tables_list = []           
            output_df_list = []
            for api_details in data_source["api_details"]:
                logger.info("api_details is -{}".format(api_details))
                logger.info("Type api_details is -{}".format(type(api_details)))
                sectrets_data = lmcu.get_secret(str(data_source["secret_name"]))
                if(api_details["is_hold"] == "Y"):
                    continue
                load_start_date = datetime.strptime('2024-05-12', '%Y-%m-%d')
                load_end_date = datetime.strptime('2024-05-13', '%Y-%m-%d')
                process_pageview_api_data(sparkSession, load_start_date, load_end_date, api_details, sectrets_data, logger, output_df_list, success_tables_list, failed_tables_list, jobName)
            data_validation_df = data_validation_df + output_df_list
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
            validation_df = data_validation_df[0]
            for i in range(1,len(data_validation_df)):
                validation_df = validation_df.unionAll(data_validation_df[i])
            validation_df.show(100,False)
            send_validation_results(validation_df, data_source["data_source"])
            logger.info("success_tables_list is - {}".format(success_tables_list))
            logger.info("failed_tables_list is - {}".format(failed_tables_list))
            failed_tables = "<br> "
            if(len(failed_tables_list) > 0):
                for item in failed_tables_list:                    
                    failed_tables += "<br> " + item
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!! except following tables, {}".format(failed_tables)
            else:
                email_body = "The Ingestion Glue job for Redshift data source has been completed Successfully..!!"
            #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", info_event_type, email_body, logger)
            logger.info("Ingestion process for the data source - {} is completed..!!".format(data_source["data_source"]))
        else:
            logger.info("data_source is not properly defined")
                    
except Exception as e:
    #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Ingestion Glue Job - lm_source_to_bronze_dev", error_event_type, "The Ingestion Glue job has been failed. Error Description is - {}".format(str(e)), logger)
    logger.info("Error occured in main method. Error - {}".format(str(e)))
    raise Exception(e)

logger.info("LM - Ingestion Glue has been completed..!!")

## Job Execution Ended..!!
glueJob.commit()