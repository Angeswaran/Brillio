import sys, boto3, datetime, json, time
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkConf, SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
import datetime
import logging
from datetime import datetime, timedelta  
from threading import Thread
import time
import pytz
#ist = pytz.timezone('Asia/Kolkata')
#from pyspark.sql.functions import *
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, IntegerType, LongType, IntegerType, StringType, FloatType, BooleanType, TimestampType

from email.utils import formataddr
from smtplib import SMTP_SSL, SMTPException
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Initializing the Logging mechanism.
logger = logging.getLogger()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)

# Getting the arguments as a parameters from outside.
args = getResolvedOptions(sys.argv, 
                    ['JOB_NAME', "config_s3_bucket", "config_s3_filepath", "utility_s3_filepath", "notification_flag", "thread_count", "multithreading_flag", "common_config_s3_bucket", "common_config_s3_filepath"])                        

jobName = args['JOB_NAME']
jobRunId = args['JOB_RUN_ID']
config_s3_bucket = args['config_s3_bucket']
config_s3_filepath = args['config_s3_filepath']
utility_s3_filepath = args['utility_s3_filepath']
notification_flag = args['notification_flag']
thread_count = int(args['thread_count'])
multithreading_flag = args['multithreading_flag']

common_config_s3_bucket = args['common_config_s3_bucket']
common_config_s3_filepath = args['common_config_s3_filepath']

# Initializing the SparkContext, GlueContext and SQL Context
conf = SparkConf()
sparkContext = SparkContext(conf=conf)
glueContext = GlueContext(sparkContext)
sparkSession = glueContext.spark_session
glueJob = Job(glueContext)
glueJob.init(args["JOB_NAME"], args)

# Add reference files
sparkSession.sparkContext.addPyFile(utility_s3_filepath)

sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInWrite","LEGACY")
# sparkSession.conf.set("spark.hadoop.hive.exec.dynamic.partition","true")
# sparkSession.conf.set("hive.exec.dynamic.partition.mode","nonstrict")
sparkSession.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")

# Import custom common functions from utility
import lm_common_utility as lmcu

s3_client = boto3.client('s3')

info_event_type = "INFO"
error_event_type = "ERROR"

def left_join_table(spark,df,join_details):
    for table in join_details:
        db_name = join_details[table]["db_name"]
        table_name = join_details[table]["table_name"]
        left_df = spark.read.table(f"{db_name}.{table_name}")
        select_col = ["a.*"] + join_details[table]["take_column"].split(",")
        df = df.alias("a").join(left_df.alias("b"),f.expr(join_details[table]["join_condition"]),"left").selectExpr(select_col)
    return df

def data_quality_check(df,qc_details,source_database_name,source_table_name,target_database,target_table,target_rejected_location,logger):
    for qc in qc_details:
        qc_accepted_df = df.filter(qc_details[qc]["quality_check_condition"])  
        quality_check_condition = qc_details[qc]["quality_check_condition"]
        logger.info(f"quality_check_conditions: {quality_check_condition}")
        qc_rejected_df = df.subtract(qc_accepted_df)
        if(qc_rejected_df.count() > 0):
            qc_rejected_df. \
                withColumn("DQ_rule",f.lit(qc)). \
                withColumn("Reason",f.lit(qc_details[qc]["description"])). \
                withColumn("is_data_restricted",f.lit(qc_details[qc]["restrict_data"])). \
                withColumn("vaidated_on", f.expr("current_date")). \
                write.mode("append").saveAsTable(f"{target_database}.{target_table}_rejected",path=target_rejected_location)
        df = qc_accepted_df if qc_details[qc]["restrict_data"] == 'Y' else df
    return df

def drop_column(df,drop_column):
    for column in drop_column.split(","):
        df = df.drop(column) if column.strip() != "" else df
    return df

def add_column(df,add_columns):
    for column in add_columns:
        df = df.withColumn(column.split(' as ')[1].strip(),f.expr(column))
    return df

def send_DQ_results(dq_df, data_source_name,logger):
    try:
        logger.info("process to the DQ rsults has been started")
        convert_df_to_html = dq_df.toPandas().to_html()
        body_html_details = f"""<html>
                <head></head>
                <body>
                <p> Please find the Failed DQ rules for {data_source_name}</p>
                {convert_df_to_html}
                </body>
                </html>"""
        lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, f"License Management - DQ Check - {data_source_name}", info_event_type, body_html_details, logger)
    except Exception as e:
        logger.error("Error occured in send_validation_results Method. Error description is - {}".format(str(e)))
        raise Exception(e)    
    
    
def process_data_scd(df,combination_keys,target_database,target_table,target_history_location):
    try:  
        if sparkSession.catalog.tableExists(f"{target_database}.{target_table}"):
            join_condition = ""
            compare_condition = ""
            cnt = 1
            source_df = df.drop("load_date")
            target_df = sparkSession.read.table(f"{target_database}.{target_table}").filter("is_active = 1") ##Active records
            source_columns = source_df.columns        
            for key in combination_keys.split(","):
                if cnt != 1:
                    join_condition += " and "
                join_condition += f"src.{key} = trg.{key}"
                cnt = 0
            cnt = 1
            ## src.id = trg.id and src.id2 = trg.id2
            
            for column in source_columns:
                if str(column) not in combination_keys.split(","):
                    if cnt != 1:
                        compare_condition += " and "
                    compare_condition += f"src.{column} = trg.{column}"
                    cnt = 0
            ## unchanged_records --> where src.name = trg.name and src.name1 = trg.name1

            join_df = source_df.alias("src").join(target_df.alias("trg"),f.expr(join_condition),"left")
            matched_record = join_df.filter("trg."+combination_keys.split(",")[0]+" is not null")
            new_record = join_df.filter("trg."+combination_keys.split(",")[0]+" is null").select("src.*")
            
            records_with_no_changes = matched_record.where(compare_condition)
            
            #records_with_changes = matched_record.subtract(records_with_no_changes).select("trg.*")
            
            updated_records = matched_record.subtract(records_with_no_changes).select("src.*")
            active_records = new_record.unionAll(updated_records) \
                                .withColumn("start_date",f.expr("current_date")) \
                                .withColumn("End_date",f.expr("cast('9999-12-31' as Date)")) \
                                .withColumn("is_active",f.lit(1)) \
                                .unionAll(records_with_no_changes.select("trg.*"))
            active_records.write.mode("overwrite").insertInto(f"{target_database}.{target_table}")

            inactive_records = target_df.filter("is_active = 1").subtract(records_with_no_changes.select("trg.*")) \
                                    .withColumn("End_date",f.expr("current_date")) \
                                    .withColumn("is_active",f.lit(0))
            inactive_records.write.mode("append").insertInto(f"{target_database}.{target_table}")
        else:
            active_records = df.drop("load_date") \
                                .withColumn("start_date",f.expr("current_date")) \
                                .withColumn("End_date",f.expr("cast('9999-12-31' as Date)")) \
                                .withColumn("is_active",f.lit(1))
            active_records.write.mode("overwrite").partitionBy("is_active").saveAsTable(f"{target_database}.{target_table}", path=target_history_location)
    except Exception as e:
        logger.info("Error occured in process_data_scd method. Error - {}".format(str(e)))
        raise Exception(e)

def process_data_is_deleted(df,combination_keys,isdeleted_column,target_database,target_table,target_location):
    try: 
        # Get latest date from df
        last_load_date = str(df.agg(f.max("load_date")).first()[0])
        # condition to filter latest load date and inactive records
        where_clause = f"load_date = '{last_load_date}' and {isdeleted_column} = 1"
        # filter inactive records
        df_inactive_record = df.where(where_clause)
        # filter active records and add row number to fetch laterst data
        df_active_record = df.filter(f"{isdeleted_column} = 0") \
              .withColumn("rn",f.expr(f"row_number() over (partition by {combination_keys},{isdeleted_column} order by load_date desc)"))
        # filter from active records df which are no more active and add it to inactive records    
        df_inactive_record_updated = df_active_record.filter("rn <> 1").drop("rn").unionAll(df_inactive_record) \
            .withColumn(f"{isdeleted_column}_new",f.lit(1)).drop(isdeleted_column) \
            .withColumnRenamed(f"{isdeleted_column}_new",isdeleted_column)  
        
        logger.info("df_inactive_record_updated is - {}".format(df_inactive_record_updated.count()))

        # apeend inactive records
        df_inactive_record_updated.write.mode("append").partitionBy(isdeleted_column).saveAsTable(f"{target_database}.{target_table}", path=target_location)
        #df_inactive_record_updated.write.mode("append").insertInto(f"{target_database}.{target_table}") 
        
        # filter from active records df which are latest active records 
        df_active_record_updated = df_active_record.filter("rn = 1").drop("rn") \
            .withColumn(f"{isdeleted_column}_new",f.lit(0)).drop(isdeleted_column) \
            .withColumnRenamed(f"{isdeleted_column}_new",isdeleted_column)

        logger.info("df_active_record_updated is - {}".format(df_active_record_updated.count()))
        # overwrite inactive records
        df_active_record_updated.write.insertInto(f"{target_database}.{target_table}", overwrite = True)
    except Exception as e:
        logger.info("Error occured in process_data_is_deleted method. Error - {}".format(str(e)))
        raise Exception(e)

def form_schema(data_parameters_in_json):
    try:
        structList = []
        for column in data_parameters_in_json:
            dataType = StringType() if data_parameters_in_json[column] == "String" else \
                        BooleanType() if data_parameters_in_json[column] == "Boolean" else \
                        TimestampType() if data_parameters_in_json[column] == "Timestamp" else \
                        LongType() if data_parameters_in_json[column] == "Long" else \
                        IntegerType() if data_parameters_in_json[column] == "Integer" else \
                        StringType()
            structList.append(StructField(column,dataType, True))
        return StructType(structList)
    except Exception as e:
        logger.info("Error occured in form_schema method. Error - {}".format(str(e)))
        raise Exception(e)

def parse_json(df, json_column, data_parameters_in_json, schema):
    try:
        parse_json_df = df.withColumn(json_column,f.from_json(f.col(json_column),schema))
        for column in data_parameters_in_json:
            parse_json_df = parse_json_df.withColumn(column,f.col(f"{json_column}.{column}"))
        return parse_json_df
    except Exception as e:
        logger.info("Error occured in parse_json method. Error - {}".format(str(e)))
        raise Exception(e)

def process_data_dedup(df,combination_keys,bronze_table_name):
    try:
        logger.info("De-duplication process for table - {} is started..!!".format(bronze_table_name))
        df_dedup = df.withColumn("rn",f.expr(f"row_number() over (partition by {combination_keys} order by load_date desc)"))
        return df_dedup.filter("rn = 1").drop("rn")
        logger.info("De-duplication process for table - {} is completed..!!".format(bronze_table_name))
    except Exception as e:
        logger.info("Error occured in process_data_dedup method. Error - {}".format(str(e)))
        raise Exception(e)

def process_bronze_data(data_source_name,table_details,output_rejected_df_list):
    try:
        logger.info("Curation process for table - {} is started..!!".format(table_details["source_table_name"]))
        
        final_rejected_df = []
        
        #Read data from bronze leyer
        df_raw = sparkSession.read.table(table_details["source_database_name"] + "." + table_details["source_table_name"])
        json_flattern_df = df_raw
        if(table_details["is_json_parser_required"] == "Y"):
            json_fields = table_details["json_fields"]
            json_column = json_fields[0]["json_column"]
            json_schema = json_fields[0]["json_schema" ]
            schema = form_schema(json_schema)
            json_flattern_df = parse_json(df_raw, json_column, json_schema,schema).drop(json_column)

        # df_scd = json_flattern_df
        # if(table_details["is_handle_isdeleted"] == "Y"):
        #     df_scd = process_data_is_deleted(json_flattern_df,table_details["combination_keys"], table_details["is_deleted_column"], table_details["target_database_name"],table_details["target_table_name"],table_details["target_location"])            

        df_dedup = json_flattern_df    
        if(table_details["is_deduplicate"] == "Y"):
            df_dedup = process_data_dedup(json_flattern_df, table_details["combination_keys"],table_details["source_table_name"])

        join_details = table_details["join_details"]
        qc_details = table_details["qc_details"]
        df_add = add_column(df_dedup,table_details["add_column"])
        df_with_join = left_join_table(sparkSession,df_add,join_details)
            
            # dq_df = data_quality_check(df_with_join,qc_details)
        dq_df = data_quality_check(df_with_join,qc_details,table_details["source_database_name"] ,table_details["source_table_name"] ,table_details["target_database_name"],table_details["target_table_name"],table_details["target_rejected_location"],logger)
            
        final_df = drop_column(dq_df,table_details["drop_column"])
        
        if(table_details["is_handle_isdeleted"] == "Y"):
            process_data_is_deleted(final_df,table_details["combination_keys"], table_details["is_deleted_column"], table_details["target_database_name"],table_details["target_table_name"],table_details["target_location"]) 
        else:
            final_df.write.mode("overwrite").saveAsTable(table_details["target_database_name"] + "." + table_details["target_table_name"], path=table_details["target_location"])
            
        if(str(qc_details).strip() != "" ):
            # rejected_df = sparkSession.read.table(table_details["target_database_name"] + "." + table_details["target_table_name"]+"_rejected").filter("vaidated_on = current_date").selectExpr("DQ_rule","Reason","is_data_restricted").distinct()
            rejected_df = sparkSession.read.table(table_details["target_database_name"] + "." + table_details["target_table_name"]+"_rejected").filter("vaidated_on = current_date").selectExpr("DQ_rule","Reason","is_data_restricted").distinct() \
                .withColumn("data_source", f.lit(data_source_name)) \
                .withColumn("source_database_name", f.lit(table_details["source_database_name"])) \
                .withColumn("source_table_name", f.lit(table_details["source_table_name"])) \
                .withColumn("target_database_name", f.lit(table_details["target_database_name"])) \
                .withColumn("target_table_name", f.lit(table_details["target_table_name"]))
                
            output_rejected_df_list.append(rejected_df)
                
            # if(final_rejected_df.count()>0):
            #     rehected_df = final_rejected_df[0]
            #     for i in range(1,len(final_rejected_df)):
            #     rehected_df = rehected_df.unionAll(final_rejected_df[i])
            #     send_DQ_results(rejected_df, table_details["target_table_name"] , logger)
                
        if(table_details["is_scd_required"] == "Y"):
                #df_target = sparkSession.read.table(f"{table_details["target_database_name"]}.{table_details["target_table_name"]}")
            df_target = sparkSession.read.table(table_details["target_database_name"] + "." + table_details["target_table_name"])
            process_data_scd(df_target,table_details["combination_keys"],table_details["target_history_database_name"],table_details["target_history_table_name"],table_details["target_history_location"])
        else:
            logger.info("History load is not required for the table - {}".format(table_details["source_table_name"]))
        
        logger.info("Curation process for table - {} is completed..!!".format(table_details["source_table_name"]))
    except Exception as e:
        #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Curation Glue Job - lm_bronze_to_silver_curation_dev", error_event_type, "The Curation Glue job has been failed. Error Description is - {}".format(str(e)), logger)
        logger.info("Error occured in process_bronze_data method. Error - {}".format(str(e)))
        raise Exception(e)

try:
    #Read configuration from config file
    config_details = lmcu.get_config_details(config_s3_bucket, config_s3_filepath)
    final_rejected_df = []
    for data_source in config_details:
        output_rejected_df_list = []
        data_source_name = data_source
        dataset_details = config_details[data_source]
        for table_details in dataset_details:
            
            process_bronze_data(data_source_name,dataset_details[table_details],output_rejected_df_list)
            
    # Send email for rejected data    
    final_rejected_df = final_rejected_df + output_rejected_df_list
    if(len(final_rejected_df)>0):
        rejected_df = final_rejected_df[0]
        for i in range(1,len(final_rejected_df)):
            rejected_df = rejected_df.unionAll(final_rejected_df[i])
            
        logger.info(f"rejected_df: {rejected_df}")
        send_DQ_results(rejected_df, data_source_name , logger)

except Exception as e:
    #lmcu.trigger_notification(common_config_s3_bucket, common_config_s3_filepath, "License Management - Curation Glue Job - lm_bronze_to_silver_curation_dev", error_event_type, "The Curation Glue job has been failed. Error Description is - {}".format(str(e)), logger)
    logger.info("Error occured in main method. Error - {}".format(str(e)))
    raise Exception(e)

## Job Execution Ended..!!
glueJob.commit()