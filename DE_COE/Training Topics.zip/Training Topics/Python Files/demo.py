def add():
    print("yes")

add()